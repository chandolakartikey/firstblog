//-----------------------------------Alert Inbox --------------------------------------------
idtapp.controller('serviceinbox', ['$scope', '$http', "$window", function ($scope, $http, $window) {
    $scope.emailFormat = /^([a-zA-Z]+[-]?[a-zA-Z0-9._]+@[a-zA-Z0-9]+\.[a-zA-Z.]{2,5}[;]?)+$/;
    $scope.date = new Date()
    $scope.previousdate = new Date($scope.date)
    $scope.previousdate.setDate($scope.date.getDate() - 1)
    $scope.cusfilter = 50;
    $scope.data = []
    $scope.ssedata = []
    $scope.orgdata = []
    $scope.ssealertdata = []
    $scope.$apply

    //    applyfilter on page redirection
    $scope.filterredirectvalue = $window.localStorage['alertfilter']
    if ($scope.filterredirectvalue == undefined) {
        $scope.filterredirectvalue = "Select Filter"
    }
    $window.localStorage.clear()
    $scope.loaddata = function () {
        $("#smallModal3").modal('show')
        $http({
                method: 'get',
                url: "/getnewsalertforuser/",
                headers: {
                    'content-Type': 'application/json'
                },
            })
            .then(successcallback, errorcallback)
    }

    function successcallback(data) {
        $("#smallModal3").modal('hide')
        $scope.orgdata = data.data["google"]
        // console.log(data.data["google"])
        $scope.ssealertdata = data.data["sse"]
        $scope.header = ["Keywords", "Title | Source | Date", "Abstract | Full Text", "Short Summary", "Article"]
        $scope.sseheader = ["Tickers", "Date | Source", "Title", "File Name", "Url"]
        $scope.$apply
        if ($scope.orgdata.length > 1 && $scope.orgdata.length > 10) {
            for (var i = 0; i <= 10; i++) {
                $scope.data.push($scope.orgdata[i])
            }
        } else {
            for (var i = 0; i <= $scope.orgdata.length - 1; i++) {
                $scope.data.push($scope.orgdata[i])
            }
        }
        if ($scope.ssealertdata.length > 1 && $scope.ssealertdata.length > 10) {
            for (var i = 0; i <= 10; i++) {
                $scope.ssedata.push($scope.ssealertdata[i])
            }
        } else {
            for (var i = 0; i < $scope.ssealertdata.length - 1; i++) {
                $scope.ssedata.push($scope.ssealertdata[i])
            }
        }
    }

    function errorcallback(data) {
        $("#smallModal3").modal('hide')
        alert("You don't have any alert. Please subscribe to any service and visit again.")
    }


    // Reload the model when filte changes
    $scope.filtervaluefun = function () {
        if ($scope.orgdata.length > 1 && $scope.orgdata.length > 10) {
            var j = 0
            for (var i = 0; i <= $scope.orgdata.length - 1; i++) {
                //                console.log($scope.orgdata[i][11])
                if ($scope.orgdata[i][11] == $scope.filtervalue || $scope.filtervalue == 'Select Filter') {
                    $scope.data.push($scope.orgdata[i])
                    j = j + 1
                    if (j == 10) {
                        break;
                    }
                }
            }
        } else {
            var j = 0
            for (var i = 0; i <= $scope.orgdata.length - 1; i++) {
                if ($scope.orgdata[i][11] == $scope.filtervalue || $scope.filtervalue == 'Select Filter') {
                    $scope.data.push($scope.orgdata[i])
                    j = j + 1
                    if (j == 10) {
                        break;
                    }
                }
            }
        }

        if ($scope.ssealertdata.length > 1 && $scope.ssealertdata.length > 10) {
            var j = 0
            for (var i = 0; i <= $scope.ssealertdata.length - 1; i++) {
                if ($scope.ssealertdata[i][3] == $scope.filtervalue || $scope.filtervalue == 'Select Filter') {
                    $scope.ssedata.push($scope.ssealertdata[i])
                    j = j + 1
                    if (j == 10) {
                        break;
                    }
                }
            }
        } else {
            var j = 0
            for (var i = 0; i < $scope.ssealertdata.length - 1; i++) {
                if ($scope.ssealertdata[i][3] == $scope.filtervalue || $scope.filtervalue == 'Select Filter') {
                    $scope.ssedata.push($scope.ssealertdata[i])
                    j = j + 1
                    if (j == 10) {
                        break;
                    }
                }
            }
        }
    }


    $scope.loadMore = function () {
        var lastindex=$scope.data.length
        if (lastindex<=$scope.orgdata.length){
            for (var i = 0; i < 3; i++) {
                if (i < $scope.orgdata.length) {
                    if ($scope.filtervalue != "Select Filter"){
                        for (var k = 0; k <= $scope.orgdata.length - 1; k++) {
                            if ($scope.orgdata[k][11] == $scope.filtervalue && k>lastindex){
                                lastindex=k
                                break
                            }
                        }
                    }
                    else{
                       var lastindex = $scope.data.length +1
                    }
                    if (lastindex<=$scope.orgdata.length-1){
                        $scope.data.push($scope.orgdata[lastindex])
                    }
                }
            }
        }

        var sselast=$scope.ssedata.length
        if (lastindex<=$scope.ssedata.length){
            for (var i = 0; i < 3; i++) {
                if (i < $scope.ssealertdata.length) {
                    if ($scope.filtervalue != "Select Filter"){
                        for (var k = 0; k <= $scope.ssealertdata.length - 1; k++) {
                            // console.log(k,lastindex)
                            if ($scope.ssealertdata[k][11] == $scope.filtervalue && k>sselast){
                                sselast=k
                                break
                            }
                        }
                    }
                    else{
                       var sselast = $scope.data.length +1
                    }
                    // $scope.data.push($scope.orgdata[lastindex])
                    if (lastindex<=$scope.ssedata.length-1){
                        $scope.ssedata.push($scope.ssealertdata[sselast])
                    }
                }
            }
        }
    }


    $scope.filterbydate = function () {
        //  check if todate is not greater then from date
        var fromdate = new Date($scope.fromdate)
        var todate = new Date($scope.todate)
        if (todate < fromdate) {
            $("#invaliddate").modal("show");
        } else {
            $scope.datedata = {
                'todate': $scope.todate,
                'fromdate': $scope.fromdate
            }
            $scope.orgdata = []
            $scope.ssedata = []
            lenofdata = $scope.data.length
            $scope.data.splice(0, lenofdata)
            lenofssedata = $scope.ssealertdata.length
            $scope.ssealertdata.splice(0, lenofssedata)
            $scope.$apply
            $scope.datedata = {
                'todate': $scope.todate,
                'fromdate': $scope.fromdate
            }
            $("#smallModal3").modal('show')
            $http({

                    method: 'post',
                    url: "/getnewsalertusingdatefilter/",
                    data: $scope.datedata,
                    headers: {
                        'content-Type': 'application/json'
                    },
                })
                .then(successcallback, errorcallback1)
        }
        $scope.closedate = function () {
            $("#invaliddate").modal('hide')
        }

    }

    function errorcallback1(data) {
        alert("Please try again!")
    }
    //    ------------------hide and display more and less-------
    $scope.displayfull = function (e) {
        var evt = e.currentTarget;
        if (angular.element(evt).text() == 'More..') {
            angular.element(evt).parent().parent().children('p').addClass("displayNo");
            angular.element(evt).html('Less..')

        } else {
            angular.element(evt).html('More..')
            angular.element(evt).parent().parent().children('p').addClass("displayYes");
        }

    }

    //    --------------------------export data to excel file
    $scope.selected = {};
    //    console.log($scope.select_all)
    $scope.exporttoexcel = function () {
        $scope.selectedrecord = []
        var j = 0
        if ($scope.select_all == true) {
            if ($scope.filtervalue == 'Select Filter') {
                $scope.selectedrecord = $scope.orgdata
            } else {
                for (i = 0; i < $scope.orgdata.length; i++) {
                    if ($scope.orgdata[i][11] == $scope.filtervalue) {
                        $scope.selectedrecord[j] = $scope.orgdata[i]
                        j = j + 1
                    }
                }
            }

        } else {
            $scope.selectedrecord = $.grep($scope.orgdata, function (row) {
                //            console.log(row)
                return $scope.selected[row]
            })
        }
        if ($scope.selectedrecord.length > 0) {
            $("#smallModal3").modal('show')
            $http({
                    method: 'post',
                    url: "/exporttoexcel/",
                    data: $scope.selectedrecord,
                    responseType: 'arraybuffer',
                    headers: {
                        'content-Type': 'application/json'
                    }
                })
                .then(successcallbackexcel, errorcallbackexcel)
        } else {
            $("#Notselected").modal('show')
        }
    }
    $scope.closeme = function () {
        $("#Notselected").modal('hide')
    }

    function successcallbackexcel(data) {
        $scope.selected = {};
        $("#smallModal3").modal('hide')
        var blob = new Blob([data.data], {
            type: 'application/octet-stream'
        })
        if (navigator.appVersion.toString().indexOf('.NET') > 0)
            window.navigator.msSaveBlob(blob, "News Alert.zip");
        else {
            var link = document.createElement('a')
            url = window.URL || $window.webkitURL;
            link.href=url.createObjectURL(blob)
            link.download = "News Alert.zip"
            document.body.appendChild(link);
            link.click();
            setTimeout(function(){
                    document.body.removeChild(link);
                    window.URL.revokeObjectURL(url);
                }, 0);
        }
        $(".googlecheckbox").prop('checked', false)
        $("#select_all").prop('checked', false)
    }

    function errorcallbackexcel() {
        $scope.selected = {};
        $("#smallModal3").modal('hide')
    }


    $scope.emailfilterednews = function () {
        if ($scope.selectedemailid == 'Others') {
            if ($scope.otheremailid.length > 0) {
                emailid = $scope.otheremailid
            } else {
                blankemaild = true;
            }
        } else {
            emailid = $scope.selectedemailid
        }
        $scope.selectedrecord = []
        var j = 0
        if ($scope.select_all == true) {
            if ($scope.filtervalue == 'Select Filter') {
                $scope.selectedrecord = $scope.orgdata
            } else {
                for (i = 0; i < $scope.orgdata.length; i++) {
                    if ($scope.orgdata[i][11] == $scope.filtervalue) {
                        $scope.selectedrecord[j] = $scope.orgdata[i]
                        j = j + 1
                    }
                }
            }
        } else {
            $scope.selectedrecord = $.grep($scope.orgdata, function (row) {
                //            console.log(row)
                return $scope.selected[row]
            })
        }

        if ($scope.selectedrecord.length > 0) {
            $scope.emaildata = {
                'data': $scope.selectedrecord,
                'emailid': emailid
            }
            $("#chooseemailid").modal('hide')
            $("#smallModal3").modal('show')
            $http({
                    method: 'post',
                    url: "/sendfilternews/",
                    data: $scope.emaildata,
                    headers: {
                        'content-Type': 'application/json'
                    }

                })
                .then(successcallbackemail, errorcallbackemail)
        } else {
            $("#chooseemailid").modal('hide')
            $("#Notselected").modal('show')
        }

    }

    function successcallbackemail(data) {
        $scope.selected = {};
        $("#smallModal3").modal('hide')
        $("#Pause").modal('show')
    }

    function errorcallbackemail() {
        $scope.selected = {};
        $("#smallModal3").modal('hide')

    }
    $scope.uncheckcheckboxes = function () {

        $(".googlecheckbox").prop('checked', false)
        $("#Pause").modal('hide')
    }
    $scope.uncheckcheckboxesforemail = function () {

        $(".googlecheckbox").prop('checked', false)
        $("#chooseemailid").modal('hide')
    }
}])

idtapp.controller("servicepage", function ($scope, userlike, getuserlike) {

    $scope.servicelike = []
    $scope.loadlike = function () {
        getuserlike.getlike().then(function (data) {
            $scope.totalsummarylike = data['totalsummarylike'];
            $scope.selfsummarylike = data['selfsummarylike'];
            $scope.totaltranslationlike = data['totaltranslationlike'];
            $scope.selftranslationlike = data['selftranslationlike'];
            $scope.totalinfographicslike = data['totalinfographicslike'];
            $scope.selfinfographicslike = data['selfinfographicslike'];
            $scope.totalgooglelike = data['totalgooglelike'];
            $scope.selfgooglelike = data['selfgooglelike'];
            $scope.totalsselike = data['totalsselike'];
            $scope.selfsselike = data['selfsselike'];
            $scope.totalTableextractorlike = data['totalTableextractorlike'];
            $scope.selfTableextractorlike = data['selfTableextractorlike'];
            $scope.totaldbpickerlike = data['totaldbpickerlike'];
            $scope.selfdbpickerlike = data['selfdbpickerlike'];
            // totalTableextractorlike
        })
    }
    $scope.calllikeapi = function (servicename) {
        userlike.callLikeApi(servicename)
        getuserlike.getlike().then(function (data) {
            $scope.totalsummarylike = data['totalsummarylike'];
            $scope.selfsummarylike = data['selfsummarylike'];
            $scope.totaltranslationlike = data['totaltranslationlike'];
            $scope.selftranslationlike = data['selftranslationlike'];
            $scope.totalinfographicslike = data['totalinfographicslike'];
            $scope.selfinfographicslike = data['selfinfographicslike'];
            $scope.totalgooglelike = data['totalgooglelike'];
            $scope.selfgooglelike = data['selfgooglelike'];
            $scope.totalsselike = data['totalsselike'];
            $scope.selfsselike = data['selfsselike'];
            $scope.totalTableextractorlike = data['totalTableextractorlike'];
            $scope.selfTableextractorlike = data['selfTableextractorlike'];
            $scope.totaldbpickerlike = data['totaldbpickerlike'];
            $scope.selfdbpickerlike = data['selfdbpickerlike'];
        })
    }
})


idtapp.factory('userlike', function ($http) {
    return {
        callLikeApi: function (servicename) {
            var servicename = {
                'servicename': servicename
            }
            $http({
                method: 'POST',
                url: '/likeApi/',
                data: servicename,
                header: {
                    'content-Type': 'application/json'
                }
            }).then(function (data) {
                callLikeApi = data
            })
        }
    }
})


idtapp.service('filtervalue', function () {
    var saveData

    function set(data) {
        saveData = data;
    }

    function get() {
        return saveData;
    }

    return {
        set: set,
        get: get
    }
})