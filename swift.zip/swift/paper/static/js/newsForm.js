//var idtapp = angular.module('idt_portal', ['infinite-scroll']);
var idtapp = angular.module('idt_portal', ['infinite-scroll', 'ngMaterial', 'angularGrid','ngRoute']);


//change angular default notation to avoid conflict with django
idtapp.config(function ($interpolateProvider) {
    $interpolateProvider.startSymbol('{[{');
    $interpolateProvider.endSymbol('}]}');
});


//register CSRFToken
idtapp.run(function ($http) {
    $http.defaults.xsrfHeaderName = 'X-CSRFToken';
    $http.defaults.xsrfCookieName = 'csrftoken';
});


///////////////////////////////////////////////////////////////////////////////////////////////
// register factory for like
idtapp.factory('getuserlike', function ($http) {
    var getuserlike = []
    return {
        getlike: function () {
            var servicename = {
                'servicename': servicename
            }
            return $http({
                method: 'post',
                url: '/googlelike',
                header: {
                    'content-Type': 'application/json'
                }
            }).then(function (data) {
                return data.data;
            })
        }
    }
})


// register common service for like
idtapp.controller('crousel', function ($scope, $compile, $window) {
    var res = ''
    $('#helloCarousel').carousel({
        interval: 3000
    })
    //    console.log($("#helloCarousel").html())
    $('#helloCarousel').on('slid.bs.carousel', '', function () {
        var $this = $(this);
        $this.children('.carousel-control').show();
        //        $compile($this)($scope)
        //        $scope.$apply();
        if ($('.carousel-inner .item:first').hasClass('.first')) {
            $this.children('.left.carousel-control').hide();
        } else if ($('.carousel-inner .item:last').hasClass('.last')) {
            $this.children('.right.carousel-control').hide();
        }
    });

    $('#helloCarousel1').carousel({
        interval: 3000

    })

    //    redirect page to alert inbox

    $scope.filternewsalert = function (filter) {
        $window.localStorage['alertfilter'] = filter
        $window.location = "\AlertInbox"
    }


    $('#helloCarousel1').on('slid.bs.carousel', '', function () {
        var $this = $(this);

        $this.children('.carousel-control').show();
        // $compile($this)($scope)
        // $scope.$apply();
        if ($('.carousel-inner .item:first').hasClass('.first')) {
            $this.children('.left.carousel-control').hide();
        } else if ($('.carousel-inner .item:last').hasClass('.last')) {
            $this.children('.right.carousel-control').hide();
        }
    });
    $(document).ready(function () {
        $compile($('#helloCarousel'))($scope)
        $scope.$apply();
    })
})


idtapp.controller('postgoogleform', function ($log, $scope, $http, userlike, getuserlike, $window) {
    //    $scope.googlelikecount = ''


    $scope.servicelike = []
    $scope.loadlike = function () {
        getuserlike.getlike().then(function (data) {
            $scope.totalgooglelike = data['totalgooglelike'];
            $scope.selfgooglelike = data['selfgooglelike'];
        })
    }
    $scope.calllikeapi = function (servicename) {
        userlike.callLikeApi(servicename)
        getuserlike.getlike().then(function (data) {
            $scope.totalgooglelike = data['totalgooglelike'];
            $scope.selfgooglelike = data['selfgooglelike'];
        })
    }

    // ----------Post google new request to database

    $scope.emailFormat = /^([a-zA-Z]+[-]?[a-zA-Z0-9._]+@[a-zA-Z0-9]+\.[a-zA-Z.]{2,5}[;]?)+$/;
    $scope.google = {}
    $scope.submitgoogleform = function () {
        // $("#GUIDELINES").modal('show')
        $("#smallModal3").modal('show')
        if ($scope.google.EmailId == 'Others') {
            $scope.google.EmailId = $scope.google.otherEmailid
        }
        $http({
                method: 'POST',
                url: '/googleApi/create/',
                data: $scope.google,
                header: {
                    'content-Type': 'application/json'
                }
            })
            .then(successCallback, errorCallback);
    };
    $scope.closegoogle = function () {
        $scope.googleForm.$setPristine();
        $scope.googleForm.$setUntouched();
    };

    function successCallback(data) {
        $("#myModal").modal('hide')
        $("#smallModal3").modal('hide')
        $scope.googleForm.$setPristine();
        $scope.googleForm.$setUntouched();
        $scope.google = {}
        $scope.google.Source = 'Google'
        $scope.google.Frequency = 'Daily'
        $scope.google.outputFormat = 'Excel'
        $scope.google.emailActivate = 'false'
        $scope.data = data.data;
        $("#ThankYougoogle").modal('show')
        //          $uibModal.open({
        //            templateUrl:'googleThankYou',
        //
        //        })
    }

    function errorCallback(error) {
        $scope.error = error.name;
        // $("#myModal").modal('hide')
        $("#smallModal3").modal('hide')
        alert("Something wrong! Please try again or reachout to IDT-China for support.")

        // $scope.googleForm.$setPristine();
        // $scope.googleForm.$setUntouched();
        // $scope.google = {}
        // $scope.google.Source = 'Google'
        // $scope.google.Frequency = 'Daily'
        // $scope.google.outputFormat = 'Excel'
        // $scope.google.emailActivate = 'false'
        // $scope.data = data.data;
    }
    $scope.redirecttoService = function () {
        $window.localStorage['filtervalue'] = '2';
        window.location = "/ServiceManager"
    }

});

idtapp.controller('postszseform', function ($log, $scope, $http, userlike, getuserlike, $window) {
    $scope.servicelike = []

    $scope.loadlike = function () {
        getuserlike.getlike().then(function (data) {
            $scope.totalsselike = data['totalsselike'];
            $scope.selfsselike = data['selfsselike'];
        })
    }
    $scope.calllikeapi = function (servicename) {
        userlike.callLikeApi(servicename)
        getuserlike.getlike().then(function (data) {
            $scope.totalsselike = data['totalsselike'];
            $scope.selfsselike = data['selfsselike'];
        })
    }
    //    redirect to service manager page

    $scope.redirecttoService = function () {
        $window.localStorage['filtervalue'] = '3';
        window.location = "/ServiceManager"
    }



    // Post new sse/szse request
    $scope.emailFormat = /^([a-zA-Z]+[-]?[a-zA-Z0-9._]+@[a-zA-Z0-9]+\.[a-zA-Z.]{2,5}[;]?)+$/;
    $scope.szse = {}
    $scope.placeholder="e.g. 6000001;620005..."
    $scope.chnageplaceholder=function(source){
        // console.log(source)
        if (source=="SGX" || source=="KRX"){
            $scope.placeholder="e.g. ICICI BANK LIMITED. etc..."
        }
        else{
            $scope.placeholder="e.g. 6000001;620005..."
        }
    }


    $scope.submitszseform = function () {
        $("#smallModal3").modal('show')
        if ($scope.szse.EmailId == 'Others') {
            $scope.szse.EmailId = $scope.szse.otherEmailid
        }

        $http({
                method: 'POST',
                url: '/szseApi/create/',
                data: $scope.szse,
                header: {
                    'content-Type': 'application/json'
                }
            })
            .then(successCallback, errorCallback);
    };
    $scope.closeszse = function () {
        $scope.szseForm.$setPristine();
        $scope.szseForm.$setUntouched();
    };

    function successCallback(data) {
        $("#SSE").modal('hide')
        $("#smallModal3").modal('hide')
        $scope.szseForm.$setPristine();
        $scope.szseForm.$setUntouched();
        $scope.szse = {}
        $scope.szse.Source = 'SSE'
        $scope.szse.Frequency = 'Daily'
        $scope.szse.HKLanguage = 'English'
        $scope.data = data.data;
        $("#ThankYou").modal('show')
        //          $uibModal.open({
        //            templateUrl:'googleThankYou',
        //
        //        })
    }

    function errorCallback(error) {
        $scope.error = error.name;
        // $("#SSE").modal('hide')
        $("#smallModal3").modal('hide')
        // $scope.szseForm.$setPristine();
        // $scope.szseForm.$setUntouched();
        // $scope.szse = {}
        // $scope.szse.Source = 'SSE'
        // $scope.szse.Frequency = 'Daily'
        // $scope.szse.HKLanguage = 'English'
        // $scope.data = data.data;
        alert("Something wrong! Please try again or reachout to IDT-China for support.")
    }
});


idtapp.controller('ToolRedirection', function ($scope, $compile) {
    $('.multi-item-carouselu .item').each(function () {
        var next = $(this).next();
        if (!next.length) {
            next = $(this).siblings(':first');
        }
        var fun = function () {
            next.children(':first-child').clone().html()
        }

        next.children(':first-child').clone().appendTo($(this));
        var txt = next.children(':first-child').clone().html()
    });

    $('#helloCarousel1').on('click', '.blueButton', function () {
        window.location = "/" + this.id
    });
    $(document).ready(function () {
        $compile($('#helloCarousel1'))($scope)
        $scope.$apply();
    })
});


idtapp.controller('Translate', ['$scope', '$http', function ($scope, $http) {

    $scope.translation = {}
    $scope.submittranslationform = function () {
        //        console.log($scope.translation)
        $("#smallModal3").modal('show')
        $http({
                method: 'post',
                url: '/translatetext/',
                data: $scope.translation,
                headers: {
                    'content-Type': 'application/json'
                },

            })
            .then(successcallback1, errorcallback)
    };

    function successcallback1(data) {
        $scope.data = data.data
        $("#smallModal3").modal('hide')
    }

    function errorcallback(error) {
        $("#smallModal3").modal('hide')
        alert("Something wrong! Please try again or reachout to IDT-China for support.")
        console.log(error.name)
    }

    $scope.UploadFile = function (files) {
        $scope.$apply(function () { //I have used $scope.$apply because I will call this function from File input type control which is not supported 2 way binding
            $scope.Message = "";
            $scope.SelectedFileForUpload = files[0];
            $scope.fileName = files[0].name;
            //            console.log($scope.fileName)
            //            $(this).files = "";
        })
    }

    $scope.submittranslationfile = function () {
        //        console.log($scope.SelectedFileForUpload)
        if (!$scope.SelectedFileForUpload) {
            $scope.fileerror = false;
            $scope.filenotselectedforupload = true

            return
        }

        if ($scope.SelectedFileForUpload && !$scope.fileerror && !$scope.sizeerror) {

            var file = $scope.SelectedFileForUpload
            var fd = new FormData()
            fd.append('file', file)
            fd.append('fsl', $scope.translation.fsl)
            fd.append('ftl', $scope.translation.ftl)
            fd.append('source', $scope.translation.source)
            $("#smallModal3").modal('show')
            $http({
                    method: 'post',
                    url: '/translatedoc/',
                    data: fd,
                    transformRequest: angular.identity,
                    headers: {
                        'content-Type': undefined,

                    },
                    responseType: 'arraybuffer',

                })
                .then(successcallback, errorcallback)
        };
    }

    function successcallback(data) {
        $scope.SelectedFileForUpload = null
        if ($scope.fileName.split(".")[1].indexOf('xls') > -1) {
            var blob = new Blob([data.data], {
                type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            })
            if (navigator.appVersion.toString().indexOf('.NET') > 0)
                window.navigator.msSaveBlob(blob, $scope.fileName.split(".")[0] + ".xls");
            else {
                var link = document.createElement('a')
                url = window.URL || $window.webkitURL;
                link.href=url.createObjectURL(blob)
                link.download = $scope.fileName.split(".")[0] + ".xls"
                document.body.appendChild(link);
                link.click();
                setTimeout(function(){
                    document.body.removeChild(link);
                    window.URL.revokeObjectURL(url);
                }, 0);

            }
        }
        //        console.log($scope.fileName.split(".")[1].indexOf('doc'))
        else if ($scope.fileName.split(".")[1].indexOf('doc') > -1) {
            //            console.log("Hiiii")
            var blob = new Blob([data.data], {
                type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
            })
            if (navigator.appVersion.toString().indexOf('.NET') > 0)
                window.navigator.msSaveBlob(blob, $scope.fileName.split(".")[0] + ".docx");
            else {
                var link = document.createElement('a')
                url = window.URL || $window.webkitURL;
                link.href=url.createObjectURL(blob)
                link.download = $scope.fileName.split(".")[0] + ".docx"
                document.body.appendChild(link);
                link.click();
                setTimeout(function(){
                    document.body.removeChild(link);
                    window.URL.revokeObjectURL(url);
                }, 0);
            }
        } else {
            //            console.log(data.data)
            tempdata = data.data
            // tempdata=tempdata
            var enc = new TextDecoder("utf-8")
            // console.log(enc.decode(data.data))
            var blob = new Blob([enc.decode(data.data).replace(/\n/g, "\r\n")], {
                type: 'text/plain'
            })

            if (navigator.appVersion.toString().indexOf('.NET') > 0)
                window.navigator.msSaveBlob(blob, $scope.fileName.split(".")[0] + ".txt");
            else {
                var link = document.createElement('a')
                url = window.URL || $window.webkitURL;
                link.href=url.createObjectURL(blob)
                link.download = $scope.fileName.split(".")[0] + ".txt"
                document.body.appendChild(link);
                link.click();
                setTimeout(function(){
                    document.body.removeChild(link);
                    window.URL.revokeObjectURL(url);
                }, 0);
            }
        }
        $scope.translationform.$setPristine();
        $scope.translationform.$setUntouched();
        $scope.translation = {}
        $scope.fileName = "";
        $scope.filesize = 0;
        $scope.files = ""
        $scope.translation.ftl = 'Afrikaans'
        $scope.translation.fsl = 'Detect Language'
        $scope.translation.tl = 'Afrikaans'
        $scope.translation.sl = 'Detect Language'
        $scope.translation.source='Google'
        $('#file').val('');
        $("#smallModal3").modal('hide')
    }

}])



idtapp.directive('fdInput', ['$parse', function ($parse)
    {
        return {
            restrict: "A",

            link: function (scope, element, attrs) {
                var model = $parse(attrs.fdInput)
                element.bind('change', function (evt) {
                    var allowedext = ["docx", "xlsx", "xls", "txt"]
                    var correctext = false
                    var data = ""
                    var files = element[0].files;
                    //                    console.log(files)
                    for (var ae in allowedext) {
                        if (files[0].name.split(".")[1] == allowedext[ae]) {
                            scope.fileName = files[0].name;
                            scope.filesize = files[0].size;
                            correctext = true
                            scope.fileerror = false;
                            scope.filenotselectedforupload = false
                            scope.$apply();
                            //                            console.log(files[0].name)
                        }
                    }
                    if (!correctext) {
                        scope.fileerror = true;
                        scope.fileName = "";
                        scope.$apply();
                    }
                    if (scope.filesize > 1024 * 1024 * 15) {
                        scope.sizeerror = true;
                    } else {
                        scope.sizeerror = false;
                    }
                    if (correctext) {
                        $parse(attrs.fdInput)
                            .assign(scope, element[0].files)
                        scope.$apply()
                    }
                    //                    evt.target.value = "";
                })
            }
        }
}])
idtapp.controller('Summary', ['$scope', '$http', function ($scope, $http) {

    $scope.summary = {}
    $scope.submitsummaryform = function () {
        $("#smallModal3").modal('show')
        $http({
                method: 'post',
                url: '/generatesummary/',
                data: $scope.summary,
                headers: {
                    'content-Type': 'application/json'
                },

            })
            .then(successcallbacksummary, errorcallback)
    };

    function successcallbacksummary(data) {

               // console.log(data)
        $scope.data = data.data
        $scope.summaryform.$setPristine();
        $scope.summaryform.$setUntouched();
        $scope.summary = {}
        $scope.fileName = "";
        $scope.filesize = 0;
        $scope.files = ""
        $scope.summary.numberofline = '4'
        $scope.summary.language = "English"
        $("#smallModal3").modal('hide')
        //        $('#file').val('');
    }

    function errorcallback(error) {
        console.log(error.name)
        $("#smallModal3").modal('hide')
        alert("Something wrong! Please try again or reachout to IDT-China for support.")
    }
    $scope.submitsummaryurlform = function () {
        $("#smallModal3").modal('show')
        //        console.log($scope.summary)
        $http({
                method: 'post',
                url: '/generatesummartfromurl/',
                data: $scope.summary,
                headers: {
                    'content-Type': 'application/json'
                },

            })
            .then(successcallback1, errorcallback)
    };

    function successcallback1(data) {
        //        console.log(data.data.originalarticle)

        $scope.urldata = data.data.summary
        $scope.originalarticle = data.data.originalarticle

        //        $scope.summary = {}
        $scope.summaryform.$setPristine();
        $scope.summaryform.$setUntouched();
        $scope.fileName = "";
        $scope.filesize = 0;
        $scope.files = ""
        $scope.summary.numberofline = '4'
        $scope.summary.language = "English"
        $("#smallModal3").modal('hide')
        //        $('#file').val('');
    }

    function errorcallback(error) {
        console.log(error.name)
        $("#smallModal3").modal('hide')
        alert("Something wrong! Please try again or reachout to IDT-China for support.")
    }
    $scope.UploadFile = function (files) {
        $scope.$apply(function () { //I have used $scope.$apply because I will call this function from File input type control which is not supported 2 way binding
            $scope.Message = "";
            $scope.SelectedFileForUpload = files[0];
            $scope.fileName = files[0].name;
            //            console.log($scope.fileName)
            //            $(this).files = "";
        })
    }
    $scope.submitsummaryfilelinks = function () {
        //        console.log($scope.SelectedFileForUpload)
        if (!$scope.SelectedFileForUpload) {
            $scope.fileerror = false;
            $scope.filenotselectedforupload = true
            return
        }
        if ($scope.SelectedFileForUpload) {

            var file = $scope.SelectedFileForUpload
            var fd = new FormData()
            fd.append('file', file)
            fd.append('noofline', $scope.summary.numberofline)
            fd.append('lang', $scope.summary.language)
            $("#smallModal3").modal('show')
            // console.log($scope.showoptions)
            if ($scope.showoptions=="Bulk Links of Articles"){
                $http({
                        method: 'post',
                        url: '/generatesummaryforfile/',
                        data: fd,
                        transformRequest: angular.identity,
                        headers: {
                            'content-Type': undefined,
                        },
                        responseType: 'arraybuffer',
                    })
                    .then(successcallback, errorcallback)
            }
            else{
                // console.log($scope.showoptions=="Bulk Summary from Link of Article")
                console.log($scope.showoptions)
                    $http({
                        method: 'post',
                        url: '/generatebulksummaryfromarticle/',
                        data: fd,
                        transformRequest: angular.identity,
                        headers: {
                            'content-Type': undefined,
                        },
                        responseType: 'arraybuffer',
                    })
                    .then(successcallback, errorcallback)
            }
        };
    }
    function successcallback(data) {
        $scope.SelectedFileForUpload = null
        //        console.log($scope.SelectedFileForUpload)
        if ($scope.fileName.split(".")[1].indexOf('xls') > -1) {
            var blob = new Blob([data.data], {
                type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            })
            if (navigator.appVersion.toString().indexOf('.NET') > 0)
                window.navigator.msSaveBlob(blob, $scope.fileName.split(".")[0] + ".xls");
            else {
                //                var blob = new Blob([data.data], {
                //                    type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
                //                })
                var link = document.createElement('a')
                url = window.URL || $window.webkitURL;
                link.href=url.createObjectURL(blob)
                link.download = $scope.fileName.split(".")[0] + ".xlsx"
                document.body.appendChild(link);
                link.click();
                setTimeout(function(){
                    document.body.removeChild(link);
                    window.URL.revokeObjectURL(url);
                }, 0);

            }
        }
        //        console.log($scope.fileName.split(".")[1].indexOf('doc'))

        $scope.summaryformfilelinks.$setPristine();
        $scope.summaryformfilelinks.$setUntouched();
        $scope.summary = {}
        $scope.fileName = "";
        $scope.filesize = 0;
        $scope.files = ""
        $scope.summary.numberofline = '4'
        $scope.summary.language = 'English'
        $('#file').val('');
        $("#smallModal3").modal('hide')
    }

}])




idtapp.controller('servicemanager', ['$scope', '$http', "$window", function ($scope, $http, $window) {

    $scope.filterdata = $window.localStorage['filtervalue']
    if ($scope.filterdata == undefined) {
        $scope.filterdata = '1'
    }
    $window.localStorage.clear();
    $scope.emailFormat = /^([a-zA-Z]+[-]?[a-zA-Z0-9._]+@[a-zA-Z0-9]+\.[a-zA-Z.]{2,5}[;]?)+$/;
    $scope.date = new Date()
    $scope.deleteid = function (val) {
        $scope.deletevalue = {
            'value': val
        };
        $scope.$apply
        $("#Delete").modal('show')
    }

    //    check if value exist after applying filter in service manager

    $scope.ifresultfound = function (ssecnt, googlecnt) {
        if (ssecnt == 0 && $scope.filtervalue == 3) {
            $("#noresultFoundSSE").modal('show')
        }
        if (googlecnt == 0 && $scope.filtervalue == 2) {
            $("#noresultFoundgoogle").modal('show')

        }
    }
    $scope.removefilter = function () {
        $scope.filtervalue = "1"
        $scope.$apply
        $("#noresultFoundSSE").modal('hide')
        $("#noresultFoundgoogle").modal('hide')
    }
    $scope.deleteselected = function () {
        $http({
                method: 'post',
                url: '/deleteservice/',
                data: $scope.deletevalue,
                headers: {
                    'content-Type': 'application/json'
                },
            })
            .then(successcallback, errorcallback)
    };

    function successcallback(data) {

        $("#Confirmation").modal('show')

    }

    function errorcallback(data) {
        alert("Something Wrong! Please try again or reachout to IDT-China for support.")
    }
    $scope.refreshpage = function () {
        window.location = "/ServiceManager"
    }


    $scope.submiteditsseform = function (sid) {
        var c = "editsse" + sid
        $scope.c = {}
        //        console.log($scope["editsse" + sid])
        $scope["editsse" + sid].ServiceID = sid
        $scope.updatedvalue
        $http({

                method: 'post',
                url: '/editsserequest/',
                data: $scope["editsse" + sid],
                headers: {
                    'content-Type': 'application/json'
                },
            })
            .then(successcallback1, errorcallback1)
    };

    function successcallback1(data) {
        $scope.updatedvalue = data.data.ServiceID

        $scope.$apply
        $("#Pause").modal('show')
    }

    function errorcallback1(data) {
        alert("Please try again!")
    }
    $scope.submiteditgoogleform = function (sid) {
        var c = "editgoogle" + sid
        $scope.c = {}

        $scope["editgoogle" + sid].ServiceID = sid
        //        console.log($scope["editgoogle" + sid])
        $http({

                method: 'post',
                url: '/editgooglerequest/',
                data: $scope["editgoogle" + sid],
                headers: {
                    'content-Type': 'application/json'
                },
            })
            .then(successcallback2, errorcallback2)
    };

    function successcallback2(data) {
        $scope.updatedvalue = data.data.ServiceID
        $scope.$apply
        $("#Pause").modal('show')
    }

    function errorcallback2(data) {
        alert("Please try again!")
    }
    $scope.showedit = function (id, e) {
        if ($('#detail' + id).attr('class').indexOf('displayYes') == -1 & $('#detail' + id).attr('class').indexOf('displayNo') == -1) {
            if ($("#" + id).attr('class').indexOf('in') == -1) {
                e.currentTarget.parentElement.parentElement.parentElement.children[0].click();
            }
            $('#edit' + id).addClass("displayYes")
            $('#detail' + id).addClass("displayNo");
        } else {
            e.currentTarget.parentElement.parentElement.parentElement.children[0].click();
            $('#edit' + id).addClass("displayYes")
            $('#detail' + id).addClass("displayNo");
            //            console.log('#edit' + id)
        }
    }
    $scope.canceledit = function (id, formname) {
        $scope[formname].$rollbackViewValue();
        if ($scope.editedsource != undefined) {
            editedsource = $scope.editedsource
            $scope[editedsource].Source = $scope.previoussourceforsse
        }

        $('#edit' + id).addClass("displayNo");
        $('#edit' + id).removeClass("displayYes");
        $('#detail' + id).removeClass("displayNo");
    }
    //     store the previous value for SSE source
    $scope.storepreviousvalue = function (preval, id) {
        $scope.editedsource = id
        $scope.previoussourceforsse = preval
    }

}])

//-----------------------------------Alert Inbox --------------------------------------------
//---------------------------------------------------------------------------------------------

idtapp.controller('serviceinbox', ['$scope', '$http', "$window", function ($scope, $http, $window) {
    $scope.emailFormat = /^([a-zA-Z]+[-]?[a-zA-Z0-9._]+@[a-zA-Z0-9]+\.[a-zA-Z.]{2,5}[;]?)+$/;
    $scope.date = new Date()
    $scope.previousdate = new Date($scope.date)
    $scope.previousdate.setDate($scope.date.getDate() - 1)
    $scope.cusfilter = 50;
    $scope.data = []
    $scope.ssedata = []
    $scope.orgdata = []
    $scope.ssealertdata = []
    $scope.$apply

    //    applyfilter on page redirection

    $scope.filterredirectvalue = $window.localStorage['alertfilter']

    if ($scope.filterredirectvalue == undefined) {
        $scope.filterredirectvalue = "Select Filter"
    }
    $window.localStorage.clear()
    $scope.loaddata = function () {
        $("#smallModal3").modal('show')
        $http({
                method: 'get',
                url: "/getnewsalertforuser/",
                headers: {
                    'content-Type': 'application/json'
                },
            })
            .then(successcallback, errorcallback)
    }

    function successcallback(data) {
        $("#smallModal3").modal('hide')
        $scope.orgdata = data.data["google"]
        // console.log(data.data["google"])
        $scope.ssealertdata = data.data["sse"]
        $scope.header = ["Keywords", "Title | Source | Date", "Abstract | Full Text", "Short Summary", "Article"]
        $scope.sseheader = ["Tickers", "Date | Source", "Title", "File Name", "Url"]
        $scope.$apply
        if ($scope.orgdata.length > 1 && $scope.orgdata.length > 10) {
            for (var i = 0; i <= 10; i++) {
                $scope.data.push($scope.orgdata[i])
            }
        } else {
            for (var i = 0; i <= $scope.orgdata.length - 1; i++) {
                $scope.data.push($scope.orgdata[i])
            }
        }
        if ($scope.ssealertdata.length > 1 && $scope.ssealertdata.length > 10) {

            for (var i = 0; i <= 10; i++) {
                $scope.ssedata.push($scope.ssealertdata[i])
            }
        } else {
            for (var i = 0; i < $scope.ssealertdata.length - 1; i++) {
                $scope.ssedata.push($scope.ssealertdata[i])
            }
        }

        // console.log($scope.orgdata[][10])
    }

    function errorcallback(data) {
        $("#smallModal3").modal('hide')
        alert("You don't have any alert. Please subscribe to any service and visit again.")

    }

    // Reload the model when filte changes

    $scope.filtervaluefun = function () {
        // $scope.data.splice(0, 11)
        // $scope.ssealertdata.splice(0, 11)
        // $scope.$apply

        if ($scope.orgdata.length > 1 && $scope.orgdata.length > 10) {
            var j = 0

            for (var i = 0; i <= $scope.orgdata.length - 1; i++) {
                //                console.log($scope.orgdata[i][11])
                if ($scope.orgdata[i][11] == $scope.filtervalue || $scope.filtervalue == 'Select Filter') {
                    $scope.data.push($scope.orgdata[i])
                    j = j + 1
                    if (j == 10) {
                        break;
                    }
                }
            }
        } else {
            var j = 0
            for (var i = 0; i <= $scope.orgdata.length - 1; i++) {
                if ($scope.orgdata[i][11] == $scope.filtervalue || $scope.filtervalue == 'Select Filter') {
                    $scope.data.push($scope.orgdata[i])
                    j = j + 1
                    if (j == 10) {
                        break;
                    }
                }
            }
        }

        if ($scope.ssealertdata.length > 1 && $scope.ssealertdata.length > 10) {
            var j = 0
            for (var i = 0; i <= $scope.ssealertdata.length - 1; i++) {
                if ($scope.ssealertdata[i][3] == $scope.filtervalue || $scope.filtervalue == 'Select Filter') {
                    $scope.ssedata.push($scope.ssealertdata[i])
                    j = j + 1
                    if (j == 10) {
                        break;
                    }
                }
            }
        } else {
            var j = 0
            for (var i = 0; i < $scope.ssealertdata.length - 1; i++) {
                if ($scope.ssealertdata[i][3] == $scope.filtervalue || $scope.filtervalue == 'Select Filter') {
                    $scope.ssedata.push($scope.ssealertdata[i])
                    j = j + 1
                    if (j == 10) {
                        break;
                    }
                }
            }
        }

    }
    $scope.loadMore = function () {

        var lastindex=$scope.data.length
        if (lastindex<=$scope.orgdata.length){
            for (var i = 0; i < 3; i++) {
                if (i < $scope.orgdata.length) {
                    if ($scope.filtervalue != "Select Filter"){
                        for (var k = 0; k <= $scope.orgdata.length - 1; k++) {
                            // console.log(k,lastindex)
                            if ($scope.orgdata[k][11] == $scope.filtervalue && k>lastindex){
                                lastindex=k
                                break
                            }
                        }
                    }
                    else{
                       var lastindex = $scope.data.length +1
                    }
                    if (lastindex<=$scope.orgdata.length-1){
                        $scope.data.push($scope.orgdata[lastindex])
                    }
                    // else{
                    //     break;
                    // }
                }
            }
        }
        var sselast=$scope.ssedata.length
        if (lastindex<=$scope.ssedata.length){
            for (var i = 0; i < 3; i++) {
                if (i < $scope.ssealertdata.length) {
                    if ($scope.filtervalue != "Select Filter"){
                        for (var k = 0; k <= $scope.ssealertdata.length - 1; k++) {
                            // console.log(k,lastindex)
                            if ($scope.ssealertdata[k][11] == $scope.filtervalue && k>sselast){
                                sselast=k
                                break
                            }
                        }
                    }
                    else{
                       var sselast = $scope.data.length +1
                    }
                    // $scope.data.push($scope.orgdata[lastindex])
                    if (lastindex<=$scope.ssedata.length-1){
                        $scope.ssedata.push($scope.ssealertdata[sselast])
                    }
                }
            }
        }
            // var sselast = $scope.ssedata.length
            // for (var i = sselast + 1; i < sselast + 3; i++) {
            //     if (i < $scope.ssealertdata.length) {
            //         $scope.ssedata.push($scope.ssealertdata[i])
            //     }
            // }
    }
    $scope.filterbydate = function () {

        //  check if todate is not greater then from date
        var fromdate = new Date($scope.fromdate)
        var todate = new Date($scope.todate)
        // console.log(todate)
        //        console.log(todate < fromdate)
        if (todate < fromdate) {
            $("#invaliddate").modal("show");
        } else {
            $scope.datedata = {
                'todate': $scope.todate,
                'fromdate': $scope.fromdate
            }
            $scope.orgdata = []
            $scope.ssedata = []
            lenofdata = $scope.data.length
            $scope.data.splice(0, lenofdata)
            lenofssedata = $scope.ssealertdata.length
            $scope.ssealertdata.splice(0, lenofssedata)
            $scope.$apply
            //        console.log($scope.data.length)
            $scope.datedata = {
                'todate': $scope.todate,
                'fromdate': $scope.fromdate
            }
            $("#smallModal3").modal('show')
            $http({

                    method: 'post',
                    url: "/getnewsalertusingdatefilter/",
                    data: $scope.datedata,
                    headers: {
                        'content-Type': 'application/json'
                    },
                })
                .then(successcallback, errorcallback1)
        }
        $scope.closedate = function () {
            $("#invaliddate").modal('hide')
        }

    }

    function errorcallback1(data) {
        alert("Please try again!")
    }
    //    ------------------hide and display more and less-------
    $scope.displayfull = function (e) {
        var evt = e.currentTarget;
        if (angular.element(evt).text() == 'More..') {
            angular.element(evt).parent().parent().children('p').addClass("displayNo");
            angular.element(evt).html('Less..')

        } else {
            angular.element(evt).html('More..')
            angular.element(evt).parent().parent().children('p').addClass("displayYes");
        }

    }

    //    --------------------------export data to excel file
    $scope.selected = {};
    //    console.log($scope.select_all)
    $scope.exporttoexcel = function () {
        $scope.selectedrecord = []
        var j = 0
        if ($scope.select_all == true) {
            if ($scope.filtervalue == 'Select Filter') {
                $scope.selectedrecord = $scope.orgdata
            } else {
                for (i = 0; i < $scope.orgdata.length; i++) {
                    if ($scope.orgdata[i][11] == $scope.filtervalue) {
                        $scope.selectedrecord[j] = $scope.orgdata[i]
                        j = j + 1
                    }
                }
            }

        } else {
            $scope.selectedrecord = $.grep($scope.orgdata, function (row) {
                //            console.log(row)
                return $scope.selected[row]
            })
        }
        if ($scope.selectedrecord.length > 0) {
            $("#smallModal3").modal('show')
            $http({
                    method: 'post',
                    url: "/exporttoexcel/",
                    data: $scope.selectedrecord,
                    responseType: 'arraybuffer',
                    headers: {
                        'content-Type': 'application/json'
                    }
                })
                .then(successcallbackexcel, errorcallbackexcel)
        } else {
            $("#Notselected").modal('show')
        }
    }
    $scope.closeme = function () {
        $("#Notselected").modal('hide')
    }

    function successcallbackexcel(data) {
        $scope.selected = {};
        $("#smallModal3").modal('hide')
        var blob = new Blob([data.data], {
            type: 'application/octet-stream'
        })
        if (navigator.appVersion.toString().indexOf('.NET') > 0)
            window.navigator.msSaveBlob(blob, "News Alert.zip");
        else {
            var link = document.createElement('a')
            url = window.URL || $window.webkitURL;
            link.href=url.createObjectURL(blob)
            link.download = "News Alert.zip"
            document.body.appendChild(link);
            link.click();
            setTimeout(function(){
                    document.body.removeChild(link);
                    window.URL.revokeObjectURL(url);
                }, 0);

        }




        $(".googlecheckbox").prop('checked', false)
        $("#select_all").prop('checked', false)
    }

    function errorcallbackexcel() {
        $scope.selected = {};
        $("#smallModal3").modal('hide')

    }

    $scope.emailfilterednews = function () {
        if ($scope.selectedemailid == 'Others') {
            if ($scope.otheremailid.length > 0) {
                emailid = $scope.otheremailid
            } else {
                blankemaild = true;
            }

        } else {
            emailid = $scope.selectedemailid
        }
        $scope.selectedrecord = []
        var j = 0
        if ($scope.select_all == true) {
            if ($scope.filtervalue == 'Select Filter') {
                $scope.selectedrecord = $scope.orgdata
            } else {
                for (i = 0; i < $scope.orgdata.length; i++) {
                    if ($scope.orgdata[i][11] == $scope.filtervalue) {
                        $scope.selectedrecord[j] = $scope.orgdata[i]
                        j = j + 1
                    }
                }
            }

        } else {
            $scope.selectedrecord = $.grep($scope.orgdata, function (row) {
                //            console.log(row)
                return $scope.selected[row]
            })
        }

        if ($scope.selectedrecord.length > 0) {
            $scope.emaildata = {
                'data': $scope.selectedrecord,
                'emailid': emailid
            }
            $("#chooseemailid").modal('hide')
            $("#smallModal3").modal('show')
            $http({
                    method: 'post',
                    url: "/sendfilternews/",
                    data: $scope.emaildata,
                    headers: {
                        'content-Type': 'application/json'
                    }

                })
                .then(successcallbackemail, errorcallbackemail)
        } else {
            $("#chooseemailid").modal('hide')
            $("#Notselected").modal('show')
        }

    }

    function successcallbackemail(data) {
        $scope.selected = {};
        $("#smallModal3").modal('hide')
        $("#Pause").modal('show')
    }

    function errorcallbackemail() {
        $scope.selected = {};
        $("#smallModal3").modal('hide')

    }
    $scope.uncheckcheckboxes = function () {

        $(".googlecheckbox").prop('checked', false)
        $("#Pause").modal('hide')
    }
    $scope.uncheckcheckboxesforemail = function () {

        $(".googlecheckbox").prop('checked', false)
        $("#chooseemailid").modal('hide')
    }
}])

idtapp.controller("servicepage", function ($scope, userlike, getuserlike) {

    $scope.servicelike = []
    $scope.loadlike = function () {
        getuserlike.getlike().then(function (data) {
            $scope.totalsummarylike = data['totalsummarylike'];
            $scope.selfsummarylike = data['selfsummarylike'];
            $scope.totaltranslationlike = data['totaltranslationlike'];
            $scope.selftranslationlike = data['selftranslationlike'];
            $scope.totalinfographicslike = data['totalinfographicslike'];
            $scope.selfinfographicslike = data['selfinfographicslike'];
            $scope.totalgooglelike = data['totalgooglelike'];
            $scope.selfgooglelike = data['selfgooglelike'];
            $scope.totalsselike = data['totalsselike'];
            $scope.selfsselike = data['selfsselike'];
            $scope.totalTableextractorlike = data['totalTableextractorlike'];
            $scope.selfTableextractorlike = data['selfTableextractorlike'];
            $scope.totaldbpickerlike = data['totaldbpickerlike'];
            $scope.selfdbpickerlike = data['selfdbpickerlike'];
            // totalTableextractorlike
        })
    }
    $scope.calllikeapi = function (servicename) {
        userlike.callLikeApi(servicename)
        getuserlike.getlike().then(function (data) {
            $scope.totalsummarylike = data['totalsummarylike'];
            $scope.selfsummarylike = data['selfsummarylike'];
            $scope.totaltranslationlike = data['totaltranslationlike'];
            $scope.selftranslationlike = data['selftranslationlike'];
            $scope.totalinfographicslike = data['totalinfographicslike'];
            $scope.selfinfographicslike = data['selfinfographicslike'];
            $scope.totalgooglelike = data['totalgooglelike'];
            $scope.selfgooglelike = data['selfgooglelike'];
            $scope.totalsselike = data['totalsselike'];
            $scope.selfsselike = data['selfsselike'];
            $scope.totalTableextractorlike = data['totalTableextractorlike'];
            $scope.selfTableextractorlike = data['selfTableextractorlike'];
            $scope.totaldbpickerlike = data['totaldbpickerlike'];
            $scope.selfdbpickerlike = data['selfdbpickerlike'];
        })
    }
})
idtapp.factory('userlike', function ($http) {

    return {
        callLikeApi: function (servicename) {
            var servicename = {
                'servicename': servicename
            }
            $http({
                method: 'POST',
                url: '/likeApi/',
                data: servicename,
                header: {
                    'content-Type': 'application/json'
                }
            }).then(function (data) {
                callLikeApi = data

            })

        }

    }
})

idtapp.service('filtervalue', function () {
    var saveData

    function set(data) {

        saveData = data;
        //        console.log(saveData)
    }

    function get() {
        return saveData;
    }

    return {

        set: set,
        get: get
    }
})

//--------------------------master controller for feedback-----------------------------
//-------------------------------------------------------------------------------------

idtapp.controller("masterctrl", ['$scope', '$http', function ($scope, $http) {

    $scope.feedback = function () {
        $("#feedbackmodal").modal('show')
    }

    $scope.sendfeedback = function () {
        var feedbackvalue = {
            feedback: $scope.feedbackvalue
        }
        $http({
                method: "post",
                url: "/feedback",
                data: feedbackvalue

            })
            .then(successcallback, errorcallback)
    }

    $scope.close = function () {
        $("#feedbackmodal").modal('hide')
        $scope.feedbackvalue = ""
    }

    function successcallback(data) {
        $("#feedbackmodal").modal('hide')
        $scope.feedbackvalue=""
    }

    function errorcallback(data) {
        $("#feedbackmodal").modal('hide')
        alert("Something wrong! Please try again or reachout to IDT-China for support.")
    }

}])
//--------------------------Angular for login---------------------------------
//------------------------------------------------------------------------------------


idtapp.controller("loginctrl",['$scope','$http',function($scope,$http){
    $scope.loginerror=false
    $scope.loginmodel={}
    $scope.logincredential = function () {
        $http({
                method: "post",
                url: "/login",
                data: $scope.loginmodel

            })
            .then(successcallback, errorcallback)
    }

    function successcallback(data) {
        $scope.login=""
        document.location.href="/";
        location.reload();
    }

    function errorcallback(data) {
        $scope.loginerror=true
        alert("Something wrong! Please try again or reachout to IDT-China for support.")

        // $scope.$apply();
    }

}])

//--------------------------Angular for infographics---------------------------------
//------------------------------------------------------------------------------------


idtapp.controller("idCo", ['$scope', '$rootScope', '$http', '$q', '$location', function($scope, $rootScope, $http, $q, $location) {  
    $scope.loadData = function () {
        $http({
            method: 'get',
            url: '/getTypesData/'
        }).then(successCallback2, errorCallback2)
    };


    function successCallback2(res) {
        $scope.category = res.data['category']
        $scope.chartType = res.data['chartType']
        $scope.hotSearch = res.data['hotSearch']
    };

    function errorCallback2(res) {
        alert("Something wrong! Please try again or reachout to IDT-China for support.")
        $scope.category = res.data['category']
        $scope.chartType = res.data['chartType']
        $scope.hotSearch = res.data['hotSearch']
    };
}]); 


//var app = angular.module('app', ['ngMaterial','angularGrid','ngRoute']);

idtapp.controller('MainCtrl', function($scope, $rootScope, $http, $q, $location, myService, $window) {
  var vm = this;
  $scope.card = {};
  $scope.card.title = 'test';
  vm.page = 0;
  vm.searchPage = 0;
  vm.shots = [];
  vm.loadingMore = false;
  vm.type;
  vm.promise;
//  vm.completed = false;


  vm.setPage = function() {
    vm.page = 0
  }

  vm.setSearchType = function() {
     vm.type = "search"
  }

  vm.setCategoryType = function() {
     vm.type = "category"
  }

  vm.setChartType = function() {
     vm.type = "chartType"
  }

  vm.enterEvent = function(e, keyword) {
     var keyCode = window.event? e.keyCode: e.which;
     if(keyCode==13){
        vm.setSearchType();
        vm.setPage();
        vm.loadMoreShots(keyword);
    }
  }

  $scope.keyword = 'Search'



  vm.getLink = function(shot) {
     if (shot[5] == null) {
        return shot[4]
     }
     return shot[5]
  }

  $scope.c_information = ''

  vm.loadMoreShots = function(keyword) {
    // console.log(keyword)
    if(vm.loadingMore) return;
//    if(vm.completed) return;
    vm.page++;
  // var deferred = $q.defer();
    vm.loadingMore = true;
//    var keyword = $scope.inputTwo

    var promise;
    if(keyword==undefined) {
        // console.log(vm.shots)
        if(vm.page==1) {
            promise = $http.get('/getInfographicsData/')
            vm.promise = promise
        }
    } else {
        if(vm.page==1) {
            if (vm.type == 'search') {
                $("#smallModal3").modal('show')
                if (typeof(keyword) == 'object') {
                    keyword = keyword.target.getAttribute("title")
                }
                data = {
                    'keyword': keyword
                }
                $scope.placeHolder = keyword
                $scope.keyword = keyword
                $scope.c_information = ''
                promise = $http.post('/search/', data)
                vm.promise = promise
                vm.loadingMore = false
            } else if (vm.type == 'category') {
                data = {
                    'Category': keyword.target.getAttribute("title")
                }
                $scope.c_information = 'Category: ' + keyword.target.getAttribute("title")
                promise = $http.post('/category/', data)
                vm.promise = promise
                vm.loadingMore = false
            } else if (vm.type == 'chartType') {
                data = {
                    'ChartType': keyword.target.getAttribute("title")
                }
                $scope.c_information = 'ChartType: ' + keyword.target.getAttribute("title")
                promise = $http.post('/chartType/', data)
                vm.promise = promise
                vm.loadingMore = false
            }

        }
    }

    // console.log($location.absUrl())
    // console.log(promise);
    if(vm.page==1) {
         promise.then(function(data) {
        //      var shotsTmp = angular.copy($scope.shots);
            if (vm.type == 'category' || vm.type == 'chartType' || vm.type == 'search') {
                $location.path('/infographicList/')
            }
            // console.log($location.absUrl())
            var shotsTmp = angular.copy(data.data.data);
            // console.log(shotsTmp)
            vm.allShots = shotsTmp
            vm.shots = shotsTmp.slice(0, 20);

            // console.log(vm.shots)
            vm.loadingMore = false;
            // console.log($location.absUrl())

            if (vm.type == 'search') {
                $("#smallModal3").modal('hide')
                if (vm.shots.length==0) {
                    $("#NoSearchResults").modal('show')
                }
                if (keyword != undefined && JSON.stringify(shotsTmp) != '[]') {
                    if (keyword.length != 1) {
                        data = {
                            'keyword': keyword
                        }
                        storeSearch = $http.post("/storeUserSearch/", data)
                    }
                }
            }
        }, function() {
          vm.loadingMore = false;
        });
    } else {
        promise = vm.promise
        promise.then(function(data) {
        //      var shotsTmp = angular.copy($scope.shots);
            if (vm.type == 'category' || vm.type == 'chartType' || vm.type == 'search') {
                $location.path('/infographicList/')
            }
            $location.path('/infographicList')
            // console.log(promise)
            // console.log($location.absUrl())
            var shotsTmp = angular.copy(vm.allShots);
            len = vm.shots.length
            if (len+20 <= vm.allShots.length) {
                vm.shots = vm.shots.concat(shotsTmp.slice(len, len+20));
                // console.log(vm.shots)
                vm.loadingMore = false;
                    //set scroll event
                if(getScrollTop() + getWindowHeight() == getScrollHeight()){
                        window.scrollTo(0, getScrollHeight()-1000)
                }
            } else {
    //            vm.shots = shotsTmp.slice(len, vm.allShots.length).concat(vm.shots);
                vm.shots = vm.shots.concat(shotsTmp.slice(len, vm.allShots.length));
                // console.log(vm.shots)
                vm.loadingMore = false;
//                vm.completed = true;
            }
        }, function() {
            vm.loadingMore = false;
        });


    }
    // console.log($location.absUrl())
    return promise;
  };

  vm.loadMoreShots();

//  vm.searchNum = function() {
//     if (vm.type == 'search') {
//        if (vm.shots.length == 0) {
//            return true
//        } else {
//            return false
//        }
//     }
//  }

   $scope.typeOfFilter = function() {
        if ($scope.c_information != '') {
            return true
        } else{
            return false
        }
    }

  $scope.hideModal = function () {
    $("#NoSearchResults").modal('hide')
    window.location.reload()
//    console.log($location.absUrl())
  }

  $scope.infoHome = function() {
    window.location.replace('/infographics')
  }

  function passDetails(shot) {
    $rootScope.shot = shot
  }
  vm.go = function ( path) {
    $location.path( path );

  };

  $scope.placeHolder = 'Search'

  $scope.focus = function() {
    $scope.placeHolder = ''
  }

  $scope.blur = function() {
    $scope.placeHolder = $scope.keyword

  }


  $scope.goDetails = function ( path, shot) {
    $location.path( path );
    $rootScope.shot = shot
    $rootScope.shot_chartTypes = []
    for (var j = 0; j < shot[2].split("|||").length; j ++ ) {
        if (shot[2].split("|||")[j].trim() != '') {
            $rootScope.shot_chartTypes.push(shot[2].split("|||")[j].trim())
        }
    }
    $rootScope.shot_categories = []
    for (var j = 0; j < shot[1].split("|||").length; j ++ ) {
        if (shot[1].split("|||")[j].trim() != '') {
            $rootScope.shot_categories.push(shot[1].split("|||")[j].trim())
        }
    }
    $window.localStorage.setItem("FirstVisitDetails", 'true')
  };

  $window.onload = function(event) {
        flag = $window.localStorage.getItem('FirstVisitDetails')
//        console.log($location.absUrl())
        if (flag == 'true') {
            $location.path('/infographicList')
            $window.localStorage.clear()
//            console.log($location.absUrl())
            $scope.$apply()
        }
    };

    //height of document
    function getScrollHeight(){
    　　var scrollHeight = 0, bodyScrollHeight = 0, documentScrollHeight = 0;
    　　if(document.body){
    　　　　bodyScrollHeight = document.body.scrollHeight;
    　　}
    　　if(document.documentElement){
    　　　　documentScrollHeight = document.documentElement.scrollHeight;
    　　}
    　　scrollHeight = (bodyScrollHeight - documentScrollHeight > 0) ? bodyScrollHeight : documentScrollHeight;
    　　return scrollHeight;
    }
    //height of browser
    function getWindowHeight(){
    　　var windowHeight = 0;
    　　if(document.compatMode == "CSS1Compat"){
    　　　　windowHeight = document.documentElement.clientHeight;
    　　}else{
    　　　　windowHeight = document.body.clientHeight;
    　　}
    　　return windowHeight;
    }

//};
});

idtapp.factory('myService', function() {
     var savedData = {}
     function set(data) {
       savedData = data;
     }
     function get() {
      return savedData;
     }

     return {
      set: set,
      get: get
     }

});

idtapp.filter('unsafe', function($sce) { return $sce.trustAsHtml; });

idtapp.filter('convert', function() {
    return function(staticUrl) {
        return staticUrl.replace('#', '%23');
    }
});

idtapp.filter('titleCase', function() {
    var titleCaseFilter = function(input) {
        var words = input.split(' ');
        for (var i = 0; i < words.length; i++) {
            words[i] = words[i].charAt(0).toUpperCase() + words[i].slice(1);
        }
        return words.join(' ');
    };
    return titleCaseFilter;
});


idtapp.config(function($routeProvider) {
    $routeProvider
        .when('/infographicList', {
            templateUrl: '/infographicList',
            controller: 'infographicController'
        })
        .when('/infographicDetails', {
            templateUrl: '/infographicDetails',
            controller: 'infographicController'
        })
        .otherwise({
            redirectTo: '/infographicList'
        });
});



idtapp.controller('infographicController', function($scope) {
//  $scope.students = [
//      {name: 'Mark Waugh', city:'New York'},
//      {name: 'Steve Jonathan', city:'London'},
//      {name: 'John Marcus', city:'Paris'}
//  ];
//
//  $scope.message = "Click on the hyper link to view the students list.";

    $scope.go = function ( path ) {
        $location.path( path );
    };
});
