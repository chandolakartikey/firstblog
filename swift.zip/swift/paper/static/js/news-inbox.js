var idtapp = angular.module('idt_portal', ['infinite-scroll', 'angularGrid' ,'localytics.directives']);


//change angular default notation to avoid conflict with django
idtapp.config(function ($interpolateProvider) {
    $interpolateProvider.startSymbol('{[{');
    $interpolateProvider.endSymbol('}]}');
});


//register CSRFToken
idtapp.run(function ($http) {
    $http.defaults.xsrfHeaderName = 'X-CSRFToken';
    $http.defaults.xsrfCookieName = 'csrftoken';
});


idtapp.controller('serviceinbox', ['$scope', '$http', "$window","$filter", function ($scope, $http, $window, $filter) {
    $scope.emailFormat = /^([a-zA-Z]+[-]?[a-zA-Z0-9._]+@[a-zA-Z0-9]+\.[a-zA-Z.]{2,5}[;]?)+$/;
    $scope.date = new Date()
    $scope.previousdate = new Date($scope.date)
    $scope.previousdate.setDate($scope.date.getDate() - 1)
    $scope.cusfilter = 50;
    $scope.data = []
    $scope.ssedata = []
    $scope.orgdata = []
    $scope.ssealertdata = []
    $scope.$apply
    $scope.filterredirectvalue = $window.localStorage['alertfilter']

    if ($scope.filterredirectvalue == undefined) {
        $scope.filterredirectvalue = "Select Filter"
    }

    $window.localStorage.clear()

    $scope.loadData = function () {
        $("#smallModal3").modal('show')
        $http({
                method: 'get',
                url: "/getnewsalertforuser/",
                headers: {
                    'content-Type': 'application/json'
                },
            })
            .then(successcallback, errorcallback)
    }

    function successcallback(data) {
        $("#smallModal3").modal('hide')
        $scope.orgdata = data.data["google"]
        $scope.ssealertdata = data.data["sse"]
        $scope.filterkeyword=[]
        for (var i = 0; i <= $scope.orgdata.length - 1; i++) {
                $scope.filterkeyword.push($scope.orgdata[i][7])
        }
        for (var i = 0; i <= $scope.ssealertdata.length - 1; i++) {
                $scope.filterkeyword.push($scope.ssealertdata[i][6])
        }

        //remove duplicate for scope.filterkeyword
        var list = $scope.filterkeyword
        var obj = {};
        var arr = [];
        for (var i = 0, len = list.length; i < len; i++){
            var kw = list[i]
            if (obj[kw]) continue;
            else{
                obj[kw] = kw;
                arr.push(kw)
            }
        }
        $scope.kwlist = arr
        //

        $scope.header = ["Keywords", "Title | Source | Date", "Abstract | Full Text", "Short Summary", "Article"]
        $scope.sseheader = ["Tickers", "Date | Source", "Title", "File Name", "Url"]
        $scope.$apply

        if ($scope.orgdata.length > 1 && $scope.orgdata.length > 10) {
            for (var i = 0; i <= 10; i++) {
                $scope.data.push($scope.orgdata[i])
            }
        } else {
            for (var i = 0; i <= $scope.orgdata.length - 1; i++) {
                $scope.data.push($scope.orgdata[i])
            }
        }

        if ($scope.ssealertdata.length > 1 && $scope.ssealertdata.length > 10) {
            for (var i = 0; i <= 10; i++) {
                $scope.ssedata.push($scope.ssealertdata[i])
            }
        } else {
            for (var i = 0; i < $scope.ssealertdata.length - 1; i++) {
                $scope.ssedata.push($scope.ssealertdata[i])
            }
        }
    }

    function errorcallback(data) {
        $("#smallModal3").modal('hide')
        alert("You don't have any alert. Please subscribe to any service and visit again.")
    }


//////////////////////////////////////////////////////////////////////////////////////////////////////////////

//transfer keyword and date range, filter keyword and date range, and load filter result
    $scope.loadFilterResult = function(){

        filter_keyword = $scope.filterKeyword
        console.log(filter_keyword)

        var fromdate = new Date($scope.fromdate)
        var todate = new Date($scope.todate)

        // 2019.3 ER added: Change Date Format to "yyyy-MM-dd"
        Date.prototype.format = function(fmt) {
             var o = {
                "M+" : this.getMonth()+1,
                "d+" : this.getDate(),
                "h+" : this.getHours(),
                "m+" : this.getMinutes(),
                "s+" : this.getSeconds(),
                "q+" : Math.floor((this.getMonth()+3)/3),
                "S"  : this.getMilliseconds()
            };
            if(/(y+)/.test(fmt)) {
                    fmt=fmt.replace(RegExp.$1, (this.getFullYear()+"").substr(4 - RegExp.$1.length));
            }
             for(var k in o) {
                if(new RegExp("("+ k +")").test(fmt)){
                     fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));
                 }
             }
            return fmt;
        }

        var oldFromDate = (new Date($scope.fromdate)).getTime();
        var curFromDate = new Date(oldFromDate).format("yyyy-MM-dd");
        $scope.FromDate = JSON.stringify(curFromDate)
        FromDate = $scope.FromDate
        console.log(FromDate);

        var oldToDate = (new Date($scope.todate)).getTime();
        var curToDate = new Date(oldToDate).format("yyyy-MM-dd");

        $scope.ToDate = JSON.stringify(curToDate)
        ToDate = $scope.ToDate
        console.log(ToDate);
        if (todate < fromdate) {
            $("#invaliddate").modal("show");
        } else {
            $scope.datedata = {
                'fromdate': $scope.FromDate,
                'todate': $scope.ToDate,
            }
            $scope.$apply
        }
        console.log($scope.datedata)

        $scope.closedate = function () {
            $("#invaliddate").modal('hide')
        }

        $http({
                method: 'POST',
                url: '/filterKeyword/',
                data: {'filter_keyword': filter_keyword, 'FromDate': FromDate, 'ToDate': ToDate},
                header: {
                    'content-Type': 'application/json'
                }
        })
        .then(successFilterCallback, errorFilterCallback);
    }

    function successFilterCallback(data){
        json_filter = JSON.parse(data.data)
//        console.log(data.data)
        $scope.filterKeyword_result = json_filter.filterKeyword_result
//        console.log(' ****************** filterKeyword results ****************** ')
//        console.log($scope.filterKeyword_result)
        //refresh orgdata to reload result
        $scope.orgdata = $scope.filterKeyword_result
        console.log($scope.orgdata)
        $scope.$apply
    }

    function errorFilterCallback(data){
    }


//transfer search input, search full text, and load search result
    $scope.loadSearchResult = function(){
        search_news = $scope.searchNews
        console.log($scope.searchNews)
        $http({
                method: 'POST',
                url: '/searchNews/',
                data: {'search_news': search_news},
                header: {
                    'content-Type': 'application/json'
                }
        })
        .then(successSearchCallback, errorSearchCallback);
    }

    function successSearchCallback(data){
        json_search = JSON.parse(data.data)
        $scope.searchNews_result = json_search.searchNews_result
//        console.log(' ****************** searchNews results ****************** ')

        //refresh orgdata to reload result
        $scope.orgdata = $scope.searchNews_result
        console.log("++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++")
        console.log($scope.orgdata)
        $scope.$apply
    }

    function errorSearchCallback(data){
    }


    // Reload the model when filter changes
    $scope.filtervaluefun = function () {
        if ($scope.orgdata.length > 1 && $scope.orgdata.length > 10) {
            var j = 0
            for (var i = 0; i <= $scope.orgdata.length - 1; i++) {
                // console.log($scope.orgdata[i][11])
                if ($scope.orgdata[i][11] == $scope.filtervalue || $scope.filtervalue == 'Select Filter') {
                    $scope.data.push($scope.orgdata[i])
                    j = j + 1
                    if (j == 10) {
                        break;
                    }
                }
            }
        } else {
            var j = 0
            for (var i = 0; i <= $scope.orgdata.length - 1; i++) {
                if ($scope.orgdata[i][11] == $scope.filtervalue || $scope.filtervalue == 'Select Filter') {
                    $scope.data.push($scope.orgdata[i])
                    j = j + 1
                    if (j == 10) {
                        break;
                    }
                }
            }
        }


        if ($scope.ssealertdata.length > 1 && $scope.ssealertdata.length > 10) {
            var j = 0
            for (var i = 0; i <= $scope.ssealertdata.length - 1; i++) {
                if ($scope.ssealertdata[i][3] == $scope.filtervalue || $scope.filtervalue == 'Select Filter') {
                    $scope.ssedata.push($scope.ssealertdata[i])
                    j = j + 1
                    if (j == 10) {
                        break;
                    }
                }
            }
        } else {
            var j = 0
            for (var i = 0; i < $scope.ssealertdata.length - 1; i++) {
                if ($scope.ssealertdata[i][3] == $scope.filtervalue || $scope.filtervalue == 'Select Filter') {
                    $scope.ssedata.push($scope.ssealertdata[i])
                    j = j + 1
                    if (j == 10) {
                        break;
                    }
                }
            }
        }
    }


    $scope.loadMore = function () {
        var lastindex=$scope.data.length
        if (lastindex<=$scope.orgdata.length){
            for (var i = 0; i < 3; i++) {
                if (i < $scope.orgdata.length) {
                    if ($scope.filtervalue != "Select Filter"){
                        for (var k = 0; k <= $scope.orgdata.length - 1; k++) {
                            // console.log(k,lastindex)
                            if ($scope.orgdata[k][11] == $scope.filtervalue && k>lastindex){
                                lastindex=k
                                break
                            }
                        }
                    }
                    else{
                       var lastindex = $scope.data.length +1
                    }
                    if (lastindex<=$scope.orgdata.length-1){
                        $scope.data.push($scope.orgdata[lastindex])
                    }
                    // else{
                    //     break;
                    // }
                }
            }
        }


        var sselast = $scope.ssedata.length
        if (lastindex<=$scope.ssedata.length){
            for (var i = 0; i < 3; i++) {
                if (i < $scope.ssealertdata.length) {
                    if ($scope.filtervalue != "Select Filter"){
                        for (var k = 0; k <= $scope.ssealertdata.length - 1; k++) {
                            // console.log(k,lastindex)
                            if ($scope.ssealertdata[k][11] == $scope.filtervalue && k>sselast){
                                sselast=k
                                break
                            }
                        }
                    }
                    else{
                       var sselast = $scope.data.length +1
                    }
                    // $scope.data.push($scope.orgdata[lastindex])
                    if (lastindex<=$scope.ssedata.length-1){
                        $scope.ssedata.push($scope.ssealertdata[sselast])
                    }
                }
            }
        }
    }

    //    -------------------------- export data to excel file
    $scope.selected = {};
    //    console.log($scope.select_all)
    $scope.exporttoexcel = function () {
        $scope.selectedrecord = []
        var j = 0
        if ($scope.select_all == true) {
            if ($scope.filtervalue == 'Select Filter') {
                $scope.selectedrecord = $scope.orgdata
            } else {
                for (i = 0; i < $scope.orgdata.length; i++) {
                    if ($scope.orgdata[i][11] == $scope.filtervalue) {
                        $scope.selectedrecord[j] = $scope.orgdata[i]
                        j = j + 1
                    }
                }
            }

        } else {
            $scope.selectedrecord = $.grep($scope.orgdata, function (row) {
                //            console.log(row)
                return $scope.selected[row]
            })
        }
        if ($scope.selectedrecord.length > 0) {
            $("#smallModal3").modal('show')
            $http({
                    method: 'post',
                    url: "/exporttoexcel/",
                    data: $scope.selectedrecord,
                    responseType: 'arraybuffer',
                    headers: {
                        'content-Type': 'application/json'
                    }
                })
                .then(successcallbackexcel, errorcallbackexcel)
        } else {
            $("#Notselected").modal('show')
        }
    }
    $scope.closeme = function () {
        $("#Notselected").modal('hide')
    }

    function successcallbackexcel(data) {
        $scope.selected = {};
        $("#smallModal3").modal('hide')
        var blob = new Blob([data.data], {
            type: 'application/octet-stream'
        })
        if (navigator.appVersion.toString().indexOf('.NET') > 0)
            window.navigator.msSaveBlob(blob, "News Alert.zip");
        else {
            var link = document.createElement('a')
            url = window.URL || $window.webkitURL;
            link.href=url.createObjectURL(blob)
            link.download = "News Alert.zip"
            document.body.appendChild(link);
            link.click();
            setTimeout(function(){
                    document.body.removeChild(link);
                    window.URL.revokeObjectURL(url);
                }, 0);
        }

        $(".googlecheckbox").prop('checked', false)
        $("#select_all").prop('checked', false)
    }


    function errorcallbackexcel() {
        $scope.selected = {};
        $("#smallModal3").modal('hide')

    }

    $scope.emailfilterednews = function () {
        if ($scope.selectedemailid == 'Others') {
            if ($scope.otheremailid.length > 0) {
                emailid = $scope.otheremailid
            } else {
                blankemaild = true;
            }

        } else {
            emailid = $scope.selectedemailid
        }
        $scope.selectedrecord = []
        var j = 0
        if ($scope.select_all == true) {
            if ($scope.filtervalue == 'Select Filter') {
                $scope.selectedrecord = $scope.orgdata
            } else {
                for (i = 0; i < $scope.orgdata.length; i++) {
                    if ($scope.orgdata[i][11] == $scope.filtervalue) {
                        $scope.selectedrecord[j] = $scope.orgdata[i]
                        j = j + 1
                    }
                }
            }

        } else {
            $scope.selectedrecord = $.grep($scope.orgdata, function (row) {
                return $scope.selected[row]
            })
        }

        if ($scope.selectedrecord.length > 0) {
            $scope.emaildata = {
                'data': $scope.selectedrecord,
                'emailid': emailid
            }
            $("#chooseemailid").modal('hide')
            $("#smallModal3").modal('show')
            $http({
                    method: 'post',
                    url: "/sendfilternews/",
                    data: $scope.emaildata,
                    headers: {
                        'content-Type': 'application/json'
                    }

                })
                .then(successcallbackemail, errorcallbackemail)
        } else {
            $("#chooseemailid").modal('hide')
            $("#Notselected").modal('show')
        }

    }


/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

    function successcallbackemail(data) {
        $scope.selected = {};
        $("#smallModal3").modal('hide')
        $("#Pause").modal('show')
    }

    function errorcallbackemail() {
        $scope.selected = {};
        $("#smallModal3").modal('hide')

    }

    $scope.uncheckcheckboxes = function () {
        $(".googlecheckbox").prop('checked', false)
        $("#Pause").modal('hide')
    }

    $scope.uncheckcheckboxesforemail = function () {
        $(".googlecheckbox").prop('checked', false)
        $("#chooseemailid").modal('hide')
    }

}])


idtapp.controller("servicepage", function ($scope, userlike, getuserlike) {
    $scope.servicelike = []
    $scope.loadlike = function () {
        getuserlike.getlike().then(function (data) {
            $scope.totalsummarylike = data['totalsummarylike'];
            $scope.selfsummarylike = data['selfsummarylike'];
            $scope.totaltranslationlike = data['totaltranslationlike'];
            $scope.selftranslationlike = data['selftranslationlike'];
            $scope.totalinfographicslike = data['totalinfographicslike'];
            $scope.selfinfographicslike = data['selfinfographicslike'];
            $scope.totalgooglelike = data['totalgooglelike'];
            $scope.selfgooglelike = data['selfgooglelike'];
            $scope.totalsselike = data['totalsselike'];
            $scope.selfsselike = data['selfsselike'];
            $scope.totalTableextractorlike = data['totalTableextractorlike'];
            $scope.selfTableextractorlike = data['selfTableextractorlike'];
            $scope.totaldbpickerlike = data['totaldbpickerlike'];
            $scope.selfdbpickerlike = data['selfdbpickerlike'];
        })
    }

    $scope.calllikeapi = function (servicename) {
        userlike.callLikeApi(servicename)
        getuserlike.getlike().then(function (data) {
            $scope.totalsummarylike = data['totalsummarylike'];
            $scope.selfsummarylike = data['selfsummarylike'];
            $scope.totaltranslationlike = data['totaltranslationlike'];
            $scope.selftranslationlike = data['selftranslationlike'];
            $scope.totalinfographicslike = data['totalinfographicslike'];
            $scope.selfinfographicslike = data['selfinfographicslike'];
            $scope.totalgooglelike = data['totalgooglelike'];
            $scope.selfgooglelike = data['selfgooglelike'];
            $scope.totalsselike = data['totalsselike'];
            $scope.selfsselike = data['selfsselike'];
            $scope.totalTableextractorlike = data['totalTableextractorlike'];
            $scope.selfTableextractorlike = data['selfTableextractorlike'];
            $scope.totaldbpickerlike = data['totaldbpickerlike'];
            $scope.selfdbpickerlike = data['selfdbpickerlike'];
        })
    }
})


idtapp.factory('userlike', function ($http) {
    return {
        callLikeApi: function (servicename) {
            var servicename = {
                'servicename': servicename
            }
            $http({
                method: 'POST',
                url: '/likeApi/',
                data: servicename,
                header: {
                    'content-Type': 'application/json'
                }
            }).then(function (data) {
                callLikeApi = data

            })

        }

    }
})

idtapp.service('filtervalue', function () {
    var saveData
    function set(data) {
        saveData = data;
    }

    function get() {
        return saveData;
    }

    return {
        set: set,
        get: get
    }
})


