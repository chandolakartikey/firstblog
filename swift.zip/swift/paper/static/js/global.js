var Video1 = document.getElementById("myVideo");

// JavaScript Document commences for IDT by - mk dated on - 3rd Mar 2017





// JavaScript Document commences for IDT by - mk dated on - 3rd Mar 2017
$(document).ready(function(){
//***************************New Custmized DatePicker *********************************************


// Instantiate the Bootstrap carousel
$('#video-carouselInner.multi-item-carousel').carousel({
  interval: false
});

// for every slide in carousel, copy the next slide's item in the slide.
// Do the same for the next, next item.
$('#video-carouselInner.multi-item-carousel .item').each(function(){
  var next = $(this).next();
  
 if (!next.length) {
    next = $(this).siblings(':first');
  }
next.children(':first-child').clone().appendTo($(this));
 
 if (next.next().length>0) {
    next.next().children(':first-child').clone().appendTo($(this));
  } else {
  	$(this).siblings(':first').children(':first-child').clone().appendTo($(this));
  }

 if (next.next().next().length>0) {
    next.next().next().children(':first-child').clone().appendTo($(this));
  } else {
  	$(this).siblings(':first').children(':first-child').clone().appendTo($(this));
  }

  
 
});



$('#v1').click(function(){
		$("#video_overlays").show()
		document.getElementById("myVideo").src = "IDTChinaVideos/Article_Summary_Generation_12Dec.mp4";
		var el = document.getElementById("playButton");
		el.className ="playButton";
		
		Video1.play();
		
	});
$('#v2').click(function(){
		$("#video_overlays").show()	
		document.getElementById("myVideo").src = "IDTChinaVideos/Machine_Translation_Tool_SWF_New_12Dec.mp4";	
		var el = document.getElementById("playButton");
		 el.className ="playButton";
		 Video1.play();
	});
$('#v3').click(function(){
			$("#video_overlays").show()
					document.getElementById("myVideo").src = "IDTChinaVideos/Google_Baidu_Service_New_12Dec.mp4";
					var el = document.getElementById("playButton");
					el.className ="playButton";	
					Video1.play();
		
	});
$('#v4').click(function(){
			$("#video_overlays").show()
					document.getElementById("myVideo").src = "IDTChinaVideos/SSE_SZSE_HKEX_Company_Announcement_Tracking_Service_12Dec.mp4";	
					var el = document.getElementById("playButton");
					el.className ="playButton";
					Video1.play();
		
	});
  $('.helpVideo').on('click', function() {
	  
  window.location.href="inrto-video.html";
});


if($('.form_datetime').length)
	{
		$(".form_datetime").datepicker({
				format: 'dd M yyyy',		
				autoclose: true
		})
}
//***************************New Custmized DatePicker *********************************************	
  
  $('.navbar-toggle').on('click', function() {
	  
  $('.navbar-collapse').toggleClass('mobFixMenu');
});
  $('#nav-icon1').click(function(){
		$(this).toggleClass('open');
	});
  
  
    
	$(window).scroll(function () {
            if ($(this).scrollTop() > 50) {
                $('#back-to-top').fadeIn();
            } else {
                $('#back-to-top').fadeOut();
            }
        });
        // scroll body to 0px on click
        $('#back-to-top').click(function () {
            $('#back-to-top').tooltip('hide');
            $('body,html').animate({
                scrollTop: 0
            }, 800);
            return false;
        });
        
        $('#back-to-top').tooltip('show');

//alert table click
		  if($('.tblArrow').length>0){
			$('.tblArrow').click(function(){
					//console.log($(this).children().hasClass("glyphicon-chevron-down"));					
					if($(this).children().hasClass("glyphicon-menu-down")){
							$(this).closest(".alertTblRow").css({"overflow":"visible", "height":"auto"});
							$(this).children().removeClass("glyphicon-menu-down").addClass("glyphicon-menu-up");
						}
					else{
							$(this).closest(".alertTblRow").css({"overflow":"hidden", "height":""});
							$(this).children().removeClass("glyphicon-menu-up").addClass("glyphicon-menu-down");
						}
		})
		}

$(".searchshow").click(function(){
        $("#divSearch").fadeIn(500);
    });


$(document).mouseup(function (e)
{
    var container = $("#divSearch");

    if (!container.is(e.target) // if the target of the click isn't the container...
        && container.has(e.target).length === 0) // ... nor a descendant of the container
    {
        container.hide();
    }
});


$('.collapse').on('shown.bs.collapse', function(){
$(this).parent().find(".fa-chevron-circle-right").removeClass("fa-chevron-circle-right").addClass("fa-chevron-circle-down");

}).on('hidden.bs.collapse', function(){
$(this).parent().find(".fa-chevron-circle-down").removeClass("fa-chevron-circle-down").addClass("fa-chevron-circle-right");
});


/* var shrinkHeader = 100;
  $(window).scroll(function() {
    var scroll = getCurrentScroll();
      if ( scroll >= shrinkHeader ) {
           $('.header').addClass('shrink');
        }
        else {
            $('.header').removeClass('shrink');
        }
  });
function getCurrentScroll() {
    return window.pageYOffset || document.documentElement.scrollTop;
    }*/
   

	
// Instantiate the Bootstrap carousel
$('.multi-item-carouselu').carousel({
  interval: false
});

// for every slide in carousel, copy the next slide's item in the slide.
// Do the same for the next, next item.
$('.multi-item-carouselu .item').each(function(){
  var next = $(this).next();
  if (!next.length) {
    next = $(this).siblings(':first');
  }
  next.children(':first-child').clone().appendTo($(this));
  
 
});

$(document).ready(function() {
	$('#helloCarousel').carousel({
		interval: false
	  
	})
  
  $('#helloCarousel').on('slid.bs.carousel', '', function() {
  var $this = $(this);

  $this.children('.carousel-control').show();

  if($('.carousel-inner .item:first').hasClass('.first')) {
	      $this.children('.left.carousel-control').hide();
  } else if($('.carousel-inner .item:last').hasClass('.last')) {
    $this.children('.right.carousel-control').hide();
  }
  });

  
  
  
  $('#helloCarousel1').carousel({
		interval: false
	  
	})
  
  $('#helloCarousel1').on('slid.bs.carousel', '', function() {
  var $this = $(this);

  $this.children('.carousel-control').show();

  if($('.carousel-inner .item:first').hasClass('.first')) {
	      $this.children('.left.carousel-control').hide();
  } else if($('.carousel-inner .item:last').hasClass('.last')) {
    $this.children('.right.carousel-control').hide();
  }
  });
  
  });
  
 (function($) {

        'use strict';

        window.sr= new scrollReveal({
          reset: true,
          move: '50px',
          mobile: true
        });

      })();

 
 
 

	 
	

 
 
 $(".active1").hover(
	  function () {
		$(this).find(".boxi").addClass("displayNo");
		$(this).find(".boxi1").addClass("displayYes");
				
	  },
	  function () {
	  $(this).find(".boxi").removeClass("displayNo");
	   $(this).find(".boxi1").removeClass("displayYes");
		
	  }
	);
	

	
	
	$(".editclick").click(
	  function (e) { 
	
	  if(e.currentTarget.parentElement.parentElement.children[0].className== "accordion-toggle collapsed")
	  {
	 e.currentTarget.parentElement.parentElement.children[0].click();
	  }
		  // $(this).parent().parent().find(["id^='collapse'"]).toggleClass("in");
		$(this).parent().parent().parent().parent().find(".panel-body").addClass("displayNo");
		$(this).parent().parent().parent().parent().find(".servicehide").addClass("displayYes")
	//	$(this).closest("h4").find("a").addClass("collapse in")

	  
	  })
		
	 

	

	
	$("#EmailYes").click(
	  function () {
		// $(this).parent().parent().find(["id^='collapse'"]).toggleClass("in");
		$(this).parent().parent().parent().next("div").addClass("displayYes").removeClass("displayNo");
				
	  }
	 
	);
	
	
	$("#EmailNo").click(
	  function () {	
		$(this).parent().parent().parent().next("div").addClass("displayNo").removeClass("displayYes");
		
						
	  }
	   

	 
	);
	
	
	
	$("#SSEEmailNo").click(
	  function () {
		// $(this).parent().parent().find(["id^='collapse'"]).toggleClass("in");
		$(this).parent().parent().parent().next("div").addClass("displayYes").removeClass("displayNo");
				
	  }
	 
	);
	
	
	$("#SSEEmailYes").click(
	  function () {	
		$(this).parent().parent().parent().next("div").addClass("displayNo").removeClass("displayYes");
	  }
	);
	
	
	
	
	
	$('.chek').click(function(){
		$('.chek').next("div").toggleClass('displayNo');
	});
});njkghikbvhk

	 $(".Pause").click(
	  function () 
	  { $(this).parent().parent().find(".pausecontent").addClass("displayNo") ;
	  }
)

$(function() {
  // We can attach the `fileselect` event to all file inputs on the page
  $(document).on('change', ':file', function() {
    var input = $(this),
        numFiles = input.get(0).files ? input.get(0).files.length : 1,
        label = input.val().replace(/\\/g, '/').replace(/.*\//, '');
    input.trigger('fileselect', [numFiles, label]);
  });

  // We can watch for our custom `fileselect` event like this
  $(document).ready( function() {
      $(':file').on('fileselect', function(event, numFiles, label) {

          var input = $(this).parents('.input-group').find(':text'),
              log = numFiles > 1 ? numFiles + ' files selected' : label;

          if( input.length ) {
              input.val(log);
          } else {
              if( log ) alert(log);
          }

      });
  });
  
  
  
  $("#read-more").text('more..')    	
$("#read-more").click(function(){
	
            $(this).text($(this).text() == 'more..' ? 'less..' : 'more..');
        });
  
});

  //$('#theCarousel').on('slid.bs.carousel', '', function() {
 //  var $this = $(this);

  //$this.children('.carousel-control').show(); 
   //$('#theCarousel').on('slid', '', checkitem);
   //checkitem();

 
//});
 
//$('#theCarousel').on('slid', '', checkitem);
//	// on document ready
//	//checkitem();
//	
//	var $this = $('#theCarousel');
//	$this.children('.right.carousel-control').click(function () {
//	checkitem();
//});
//	$this.children('.left.carousel-control').click(function () {
//	checkitem();
// });





		

		
	
/*function checkitem()                        // check function
	{
	  var $this = $('#theCarousel');
	  if($('.carousel-inner .item:first').hasClass('active')) {
		$this.children('.left.carousel-control').hide();
		$this.children('.right.carousel-control').show();
		console.log("pass 1")
	  } else if($('.carousel-inner .item:last').hasClass('active')) {
		$this.children('.left.carousel-control').show();
		$this.children('.right.carousel-control').hide();
		console.log("pass2")
	  } else {
		$this.children('.carousel-control').show();
			console.log("pass 3")
	
	  } 
	}*/
	
	
	
	
	