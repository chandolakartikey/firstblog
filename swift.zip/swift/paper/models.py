from __future__ import unicode_literals

from django.db import models, connections


# table for storing news after extracting the full text
class InsertSum(models.Model):
    Url = models.TextField()
    Abstract = models.TextField(max_length=200)
    Title = models.TextField()
    S_Desc = models.TextField()
    L_Desc = models.TextField()
    article = models.TextField()
    Keyword = models.TextField()
    P_date = models.TextField()
    SendFlag = models.TextField(default="Null")
    source = models.TextField(max_length=50, default="Null")
    Newssource = models.TextField(max_length=20, default="Google")

    def __str__(self):
        return str(self.article)


# class InsertUserRequest(models.Model):
#     EmailId=models.TextField()
#     Keyword=models.TextField()
#     Frequency=models.TextField()
#     Source=models.TextField()

# table for storing comany accouncement
class Storestockexchange(models.Model):
    Title = models.TextField(max_length=500, default="Null")
    Url = models.TextField(max_length=200)
    date = models.TextField(max_length=10)
    Filename = models.TextField(max_length=50)
    SendFlag = models.TextField(max_length=100)
    Source = models.TextField(max_length=20)
    Keyword = models.TextField(max_length=20)


# table for storing news links, abstract on temp basis before extracting the full text
class googlenewsfromoutlook(models.Model):
    Url = models.TextField(max_length=1000)
    Title = models.TextField(max_length=1000)
    Date = models.DateField()
    Keyword = models.TextField(max_length=50)
    Abstract = models.TextField(max_length=200)
    Newssource = models.TextField(max_length=20)
    source = models.TextField(max_length=20, default="Null")


# table for storing new request for news update
class newRequestdetails(models.Model):
    ServiceID = models.TextField(max_length=20)
    Keyword = models.TextField()
    Source = models.TextField(max_length=20)
    Frequency = models.TextField(max_length=20)
    fromDate = models.DateField(blank=True, null=True)
    toDate = models.DateField(blank=True, null=True)
    outputFormat = models.TextField(max_length=10)
    emailActivate = models.BooleanField(default=False)
    emailAttachment = models.TextField(max_length=10, blank=True, null=True)
    EmailId = models.TextField(max_length=500, blank=True, null=True)
    Summary = models.TextField(max_length=10, default=True)
    Userid = models.TextField(max_length=50, blank=True, null=True)


# table for storing new user for company announcement
class szseRequestdetails(models.Model):
    ServiceID = models.TextField(max_length=20)
    Keyword = models.TextField()
    Source = models.TextField(max_length=50)
    Frequency = models.TextField(max_length=20)
    EmailId = models.TextField(max_length=500, blank=True, null=True)
    Userid = models.TextField(max_length=50, blank=True, null=True)
    Filterkeyword = models.TextField(max_length=1000, null=True)


# table for storing language code from google
class languagecode(models.Model):
    Language = models.TextField(max_length=50)
    code = models.TextField(max_length=10)


# table for storing last project id
class storeprojectid(models.Model):
    projectid = models.TextField(max_length=15, default="1001")


# table for storing tools or services like by user
class storeuserlike(models.Model):
    Userid = models.TextField(max_length=50)
    serviceName = models.TextField(max_length=50)
    numberOfLike = models.TextField(max_length=15, default='0')


# table for storing number of time tool used by user
class numberoftooluser(models.Model):
    toolname = models.TextField(max_length=50)
    usercount = models.IntegerField()
    Userid = models.TextField(max_length=50, default=True)


# table for storing Singapore comany list
class getlatestsgcompany(models.Model):
    company_name = models.TextField(max_length=1000)