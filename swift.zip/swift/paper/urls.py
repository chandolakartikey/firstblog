from django.conf.urls import url
import views

urlpatterns = [
    url(r'^AlertInbox/$', views.Home, name='InboxHome'),
    url(r'^getnewsalertforuser/$', views.getnewsalertforuser, name='searchInbox'),
    url(r'^filterKeyword/$', views.filterKeyword, name='filterKeyword'),
    url(r'^searchNews/$', views.searchNews, name='searchNews'),
]




