from django.contrib import admin
from paper.models import newRequestdetails
from paper.models import InsertSum

admin.site.register(InsertSum)


class insertuseradmin(admin.ModelAdmin):
    list_display = ('ServiceID', 'EmailId', 'Keyword')


admin.site.register(newRequestdetails, insertuseradmin)
# Register your models here.
# Register your models here.








