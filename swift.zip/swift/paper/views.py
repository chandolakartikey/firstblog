# -*- coding:utf-8 -*-

from __future__ import unicode_literals
from django.shortcuts import render, redirect
from rest_framework import status
from rest_framework.response import Response
from models import newRequestdetails, languagecode, storeprojectid, szseRequestdetails, InsertSum, Storestockexchange, storeuserlike,numberoftooluser
# from serializers import requestSerializer,szseSerializer,szseupdateSerializer,googleupdateSerializer
from rest_framework.decorators import api_view
# from TranslationApis import googletranslation

import logging
log = logging.getLogger(__name__)
# from forms import fileUpload,summaryfileupload
from django.http import StreamingHttpResponse, HttpResponse
# from papercelery import WriteToExcel, WriteToWord, WriteFilterNewsToExcel, SendFilterNewsToOutlook,sendgoogletoidt,WriteToText,sendfeedback,sendeditedrequesttoIDT
# from papercelery import WritesummaryfromlinkToExcel,downloadfulltext,WritesummaryfromArticleToExcel
# from summaryApi import ChineseArticle, lex_rank_summary, gensim_summary, Lsa_summary
# from newspaper import Article
from django.db.models import Q, Sum
from datetime import date, timedelta, datetime
# from Like import storeLike, toolcount
from django.conf import settings
from django.contrib.auth import authenticate, login
# from django_auth_ldap.backend import LDAPBackend
from django.contrib.auth import get_user_model
# from baidutranslation import _baidutoexcel
from langdetect import detect
# import ldap, os
import re
# from operator import *
import inflect
p = inflect.engine()
import pyodbc
import pandas as pd
import numpy as np


try:
    from django.utils import simplejson as json
except:
    import simplejson as json


def Home(request):
    return render(request, 'alert-inbox.html')


@api_view(['Post'])
def filterKeyword(request):
    if request.method == 'POST':
        Keyword = request.data['filter_keyword']
        print Keyword
        FromDate = eval(request.data['FromDate'])
        ToDate = eval(request.data['ToDate'])
        print FromDate
        print ToDate
        print ToDate

        kw_filter = Q(Keyword__in=Keyword) & Q(P_date__gte=FromDate) & Q(P_date__lte=ToDate)
        result_list = list(InsertSum.objects.filter(kw_filter).values_list())

        filter_result = []
        for row in result_list:
            filter_result.append(row)
        result = {"filterKeyword_result": filter_result}
        data = json.dumps(result)
        # print data
        return Response(data, status=status.HTTP_201_CREATED)


@api_view(['Post'])
def searchNews(request):
    if request.method == 'POST':

        search_input = request.data['search_news']
        news_list = []

        a = " OR "
        b = " AND "

        # 1. OR: either of the keywords
        if a in search_input:
            kw_list = re.split(a, search_input)
            print "OR"
            print kw_list
            for kw in kw_list:
                news_list = list(InsertSum.objects.filter(Q(Abstract__icontains=kw)).values_list())

        # 2. AND: all of the keywords
        if b in search_input:
            kw_list = re.split(b, search_input)
            AND_filter = ""
            for keyword in kw_list:
                AND_filter = AND_filter + "Q(Abstract__icontains='" + keyword + "') & "
            AND_filter = AND_filter[:-3]
            print "AND"
            print AND_filter
            exec("news_list = list(InsertSum.objects.filter(" + AND_filter + ").values_list())")

        # 3. single keyword
        if a not in search_input and b not in search_input:
            print "single keyword"
            print search_input
            news_list = list(InsertSum.objects.filter(Q(Abstract__icontains=search_input)).values_list())

        news_result = []
        for row in news_list:
            news_result.append(row)
        result = {"searchNews_result": news_result}
        search_data = json.dumps(result)
        return Response(search_data, status=status.HTTP_201_CREATED)


@api_view(['get'])
def getnewsalertforuser(request):
    # user_name=request.META['REMOTE_USER'].split("\\")[1]
    # if 'username' in request.session:
    #     user_name=request.session["username"]
    #     o=open('login.txt','r')
    #     if user_name.lower() in o.read():
    #         o.close()
    #     else:
    #         return render(request,"login.html")
    #     user_name=user_name.split("@")[0]
    # else:
    #     return render(request,"login.html")
    fromDate = date.today()-timedelta(360)
    # fromDate = date.today() - timedelta(1)
    toDate = date.today()
    try:
        data = getfilternews("cathy.feng", fromDate, toDate)
        # print data
    except Exception as e:
        print e
    response = HttpResponse(data, content_type='application/json', status=status.HTTP_201_CREATED)
    return response


def getfilternews(user_name, fromDate, toDate):
    result = []
    sseresult = []
    # user_name=request.META['REMOTE_USER'].split("\\")[1]
    googleservice = newRequestdetails.objects.filter(Q(Userid=user_name)).values_list('Keyword', 'Source')
    sseservice = szseRequestdetails.objects.filter(Q(Userid=user_name)).values_list('Keyword', 'Source')

    if googleservice:
        try:
            for row in googleservice:
                source = row[1]
                keyword = row[0].split(";")
                # log.error(keyword)
                newsdata = InsertSum.objects.filter(
                    Q(Keyword__in=keyword) & Q(Newssource=source) & Q(P_date__gte=(fromDate)) & Q(
                        P_date__lte=(toDate))).values_list().order_by('-P_date')
                for data in newsdata:
                    lst = [item[1] for item in result]
                    # log.error(data[11])
                    if data[1] in lst:
                        pass
                    else:
                        result.append(data)
        except Exception as e:
            log.error(e)
    if sseservice:
        try:
            for row in sseservice:
                source = row[1][:4]
                log.error(source)
                keyword = row[0].split(";")
                ssedata = list(Storestockexchange.objects.filter(
                    Q(Keyword__in=keyword) & Q(Source=source) & Q(date__gte=(fromDate)),
                    Q(date__lte=(toDate))).values_list().order_by('-date'))
                log.error(ssedata)
                for data in ssedata:
                    if data in sseresult:
                        pass
                    else:
                        sseresult.append(data)
        except Exception as e:
            log.error(e)
    try:
        context = {'google': result, 'sse': sseresult}
        data = json.dumps(context)
        return data
    except Exception as e:
        log.error(e)






