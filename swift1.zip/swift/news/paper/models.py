from django.db import models


# Create your models here.
class InsertSum(models.Model):
    Url = models.TextField()
    Abstract = models.TextField(max_length=200)
    Title = models.TextField()
    S_Desc = models.TextField()
    L_Desc = models.TextField()
    article = models.TextField()
    Keyword = models.TextField()
    P_date = models.TextField()
    SendFlag = models.TextField(default="Null")
    source = models.TextField(max_length=50, default="Null")
    Newssource = models.TextField(max_length=20, default="Google")

    def __str__(self):
        return str(self.article)
