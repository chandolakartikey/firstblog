from .models import InsertSum
import django_filters


class UserFilter(django_filters.FilterSet):
    class Meta:
        model = InsertSum
        fields = '__all__'
