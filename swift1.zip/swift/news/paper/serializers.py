from rest_framework import serializers
from paper.models import InsertSum


class InsertSumSerializer(serializers.ModelSerializer):
    class Meta:
        model = InsertSum
        fields = '__all__'
