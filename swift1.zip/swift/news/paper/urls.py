from rest_framework.routers import DefaultRouter
from .views import InsertSumViewset

router = DefaultRouter()
router.register('insertsum', InsertSumViewset)
urlpatterns = router.urls
