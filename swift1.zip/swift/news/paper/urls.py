from rest_framework.routers import DefaultRouter
# from .views import InsertSumViewset
from .views import InsertSumView
from django.urls import path


urlpatterns = [
    path("insert/", InsertSumView.as_view()),
    # path("polls/<int:pk>/", PollDetail.as_view(), name="polls_detail")
]

# router = DefaultRouter()
# router.register('insertsum', InsertSumViewset)
# urlpatterns = router.urls
