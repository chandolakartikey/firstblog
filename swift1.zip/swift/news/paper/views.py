from django.shortcuts import render
from paper.models import InsertSum
from paper.serializers import InsertSumSerializer
from rest_framework import viewsets, filters
from django.core.serializers import serialize
from django.contrib.auth.decorators import login_required

# @login_required
class InsertSumViewset(viewsets.ModelViewSet):
    queryset = InsertSum.objects.all()
    serializer_class = InsertSumSerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['Abstract', 'article', 'Url', 'Title', 'S_Desc', 'L_Desc', 'Keyword', 'P_date', 'SendFlag',
                     'source', 'Newssource']
    # ['clientName', 'subscriptionKey', 'status']

    # def post_list(request):
    #     return render(request, 'demo.html', {})
