from django.shortcuts import render
from paper.models import InsertSum
from paper.serializers import InsertSumSerializer
from rest_framework import viewsets, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from django.core.serializers import serialize
from django.contrib.auth.decorators import login_required
from rest_framework.views import APIView
from rest_framework.response import Response
from .filters import UserFilter
from django.db.models import F, Q, When


class InsertSumView(APIView):
    def get(self, request):
        # list1 = self.request.query_params.get('fields').split(',') if self.request.query_params.get('fields') is not None else None
        # print(list1)
        # ID = self.request.query_params.get('id').split(',') if self.request.query_params.get('id') is not None else None
        # print(ID)
        # newsource = self.request.query_params.get('Newssource')if self.request.query_params.get('Newssource') is not None else None
        # print(newsource)
        # keyword = self.request.query_params.get('Keyword') if self.request.query_params.get('Keyword') is not None else None
        # print(keyword)
        keyword = request.data['filter_keyword'] if request.data('filter_keyword') is not None else None
        FromDate = eval(request.data['FromDate']) if request.data('FromDate') is not None else None
        ToDate = eval(request.data['ToDate']) if request.data('ToDate') is not None else None
        if None not in (keyword, FromDate, ToDate):
            fl = Q(P_date__gte=FromDate) & Q(P_date__lte=ToDate) & Q(Keyword=keyword)
        elif None not in(FromDate, ToDate):
            fl = Q(P_date__gte=FromDate) | Q(P_date__lte=ToDate) | Q(Keyword=keyword)
        print(fl)
        if fl:
            insert = InsertSum.objects.filter(fl)
        else:
            insert = InsertSum.objects.all()
        print(insert.count())
        # user_filter = UserFilter(request.GET, queryset=insert).data
        # # data = InsertSumSerializer(user_filter, many=True).data
        # return render(request, 'base.html', {'filter': user_filter})
        return Response(insert)

#  @login_required
# class InsertSumViewset(viewsets.ModelViewSet):
#
#     queryset = InsertSum.objects.all()
#     serializer_class = InsertSumSerializer
#     filter_backends = [filters.SearchFilter]
#     search_fields = ['Abstract', 'article', 'Url', 'Title', 'S_Desc', 'L_Desc', 'Keyword', 'P_date', 'SendFlag',
#                      'source', 'Newssource']
#

# @action(detail=False, methods=['Get'], url_path='Keyarticle')
# def Customsearch(self, request, *args, **kwargs):
#     list = self.request.query_params.get('Keyword', None).split(',') if self.request.query_params.get('Keyword',
#                                                                                                       None) is not None else None
#     print(list)
#     queryset = None
#     if list is not None:
#         print(list)
#         queryset = InsertSum.objects.filter(Keyword=list).values('Abstract', 'article', 'Url', 'Title', 'S_Desc', 'L_Desc', 'Keyword', 'P_date', 'SendFlag',
#                  'source', 'Newssource')
#         print(queryset)
#     else:
#         queryset = InsertSum.objects.all().values('Abstract', 'article', 'Url', 'Title', 'S_Desc', 'L_Desc', 'Keyword', 'P_date', 'SendFlag',
#                  'source', 'Newssource')
#         print(queryset)
#     return Response({'result': queryset})
