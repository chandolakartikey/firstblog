from django.shortcuts import render, HttpResponse


# Create your views here.
def home(request):
    print(request)
    print(render(request, 'accounts/login.html'))
    return render(request, 'accounts/login.html')
