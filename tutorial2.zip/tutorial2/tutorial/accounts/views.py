from django.shortcuts import render, HttpResponse


# Create your views here.
def home(request):
    # print(request)
    # print(render(request, 'accounts/login.html'))
    number = {1, 2, 3, 4, 5}
    name = 'Kartikey'
    args={"name": name, "numbers": number}
    return render(request, 'accounts/home.html', args)
